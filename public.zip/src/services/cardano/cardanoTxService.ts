/**
 * Cardano transactions, built from arithmetic instead of from a wallet library.
 *
 * Everything here is pure: it takes UTxOs, protocol parameters and a destination, and returns the
 * bytes a provider would submit. No network, no key material, no clock. That is what makes coin
 * selection and fee calculation testable against fabricated UTxOs, which is the only way to
 * exercise the borders — dust change, a balance that covers the amount but not the fee — without
 * arranging them on a real chain first.
 *
 * **Why hand-rolled CBOR.** The transaction body is a canonical CBOR map with four integer keys,
 * and its blake2b-256 hash is the transaction id. Pulling in a serialization library would add a
 * WASM dependency to sign four fields, and would not remove the need to understand them: the fee
 * depends on the serialized size, so the encoder is part of the fee calculation and not a detail
 * underneath it.
 *
 * **A UTxO holding native assets is spendable like any other**, on both paths: whatever tokens the
 * selected inputs carry come back in the change output. They are reached for last, because carrying
 * them grows the transaction and the transaction size is the fee — but reached for, which is what
 * keeps a wallet from being locked out of ADA that happens to be sharing an output with a token.
 */

import { blake2b } from '@noble/hashes/blake2';

import type {
  BuiltCardanoTransaction,
  CardanoAsset,
  CardanoAssetAmount,
  CardanoProtocolParameters,
  CardanoTransferPlan,
  CardanoUtxo,
  CardanoVkeyWitness
} from '../../types/cardanoType';
import { assetUnit } from '../../types/cardanoType';
import {
  array,
  bytes,
  bytesToHex,
  CBOR_NULL,
  CBOR_TRUE,
  compareCborKeys,
  hexToBytes,
  map,
  set,
  uint
} from './cardanoCborService';
import type { CardanoStakingCertificate, CardanoWithdrawal } from './cardanoCertificateService';
import { encodeCertificates, encodeWithdrawals } from './cardanoCertificateService';

/** Constant overhead the ledger adds to a UTxO's serialized size when charging for it. */
const UTXO_ENTRY_SIZE_OVERHEAD = 160n;

/** Size of a transaction id, and of the blake2b digest that produces one. */
const TX_ID_BYTES = 32;

/** Size of a raw Ed25519 public key. */
const PUBLIC_KEY_BYTES = 32;

/** Size of a raw Ed25519 signature. */
const SIGNATURE_BYTES = 64;

/**
 * Ceiling on the build loop. Each pass can only raise the fee, and the fee raises the size by at
 * most a byte or two, so convergence takes two or three passes; more than this is a defect.
 */
const MAX_FEE_PASSES = 8;

/**
 * The minimum lovelace an output is allowed to hold, given its own size.
 *
 * An output below this is not a small payment: the ledger rejects the whole transaction. It is what
 * decides whether change can exist as its own UTxO or has to go somewhere else.
 *
 * @param output - The serialized output being priced.
 * @param coinsPerUtxoByte - Protocol parameter, lovelace per byte.
 * @returns The minimum the output must hold, in lovelace.
 */
export function minimumAdaForOutput(output: Uint8Array, coinsPerUtxoByte: bigint): bigint {
  return (UTXO_ENTRY_SIZE_OVERHEAD + BigInt(output.length)) * coinsPerUtxoByte;
}

/**
 * Serializes a `multiasset`: `{ policy_id => { asset_name => quantity } }`.
 *
 * @param assets - The assets to encode. Quantities of zero are dropped: the ledger has no
 *   representation for "zero of an asset" inside a value, and emitting one is a malformed output.
 * @returns The canonical CBOR of the multiasset map.
 */
function encodeMultiasset(assets: readonly CardanoAssetAmount[]): Uint8Array {
  const byPolicy = new Map<string, Map<string, bigint>>();
  for (const asset of assets) {
    if (asset.quantity <= 0n) continue;
    const policyId = asset.policyId.toLowerCase();
    const assetName = asset.assetName.toLowerCase();
    const names = byPolicy.get(policyId) ?? new Map<string, bigint>();
    names.set(assetName, (names.get(assetName) ?? 0n) + asset.quantity);
    byPolicy.set(policyId, names);
  }

  const policies = [...byPolicy.keys()].sort(compareCborKeys);
  return map(
    policies.map((policyId) => {
      const names = byPolicy.get(policyId)!;
      const sortedNames = [...names.keys()].sort(compareCborKeys);
      return [
        bytes(hexToBytes(policyId)),
        map(
          sortedNames.map(
            (assetName) => [bytes(hexToBytes(assetName)), uint(names.get(assetName)!)] as const
          )
        )
      ] as const;
    })
  );
}

/**
 * A `value`: bare coin when there are no tokens, `[coin, multiasset]` when there are.
 *
 * The two forms are not interchangeable. Wrapping a token-free value in the array form is accepted
 * by some tools and rejected by others, and it changes the size the fee is charged for.
 */
export function encodeValue(lovelace: bigint, assets: readonly CardanoAssetAmount[]): Uint8Array {
  const positive = assets.filter((asset) => asset.quantity > 0n);
  return positive.length === 0
    ? uint(lovelace)
    : array([uint(lovelace), encodeMultiasset(positive)]);
}

/** A `transaction_output` in the legacy array form: address bytes and the value it holds. */
export function encodeOutput(
  addressBytes: Uint8Array,
  lovelace: bigint,
  assets: readonly CardanoAssetAmount[] = []
): Uint8Array {
  return array([bytes(addressBytes), encodeValue(lovelace, assets)]);
}

/** A `transaction_input`: the id of the transaction that created the output, and its index. */
function encodeInput(utxo: CardanoUtxo): Uint8Array {
  return array([bytes(hexToBytes(utxo.txHash)), uint(utxo.outputIndex)]);
}

/** The two body fields staking adds to a transfer: certificates and reward withdrawals. */
export interface CardanoStakingBodyFields {
  certificates?: readonly CardanoStakingCertificate[];
  withdrawals?: readonly CardanoWithdrawal[];
}

/**
 * Serializes a `transaction_body`.
 *
 * @param inputs - Outputs being spent.
 * @param outputs - Already-serialized outputs, in order.
 * @param fee - Fee in lovelace.
 * @param ttlSlot - Slot after which the transaction is no longer valid.
 * @returns The canonical CBOR of the body.
 */
function encodeBody(
  inputs: readonly CardanoUtxo[],
  outputs: readonly Uint8Array[],
  fee: bigint,
  ttlSlot: number,
  staking: CardanoStakingBodyFields = {}
): Uint8Array {
  const entries: (readonly [Uint8Array, Uint8Array])[] = [
    [uint(0), set(inputs.map(encodeInput))],
    [uint(1), array(outputs)],
    [uint(2), uint(fee)],
    [uint(3), uint(ttlSlot)]
  ];

  // Keys 4 and 5, in ascending order after the four a transfer needs. A key out of order is a
  // different body, and a different body is a different transaction id.
  //
  // Absent rather than empty when there is nothing to say: `certificates` is a *non-empty* set and
  // `withdrawals` a non-empty map, so emitting either with no members is malformed CBOR, not a
  // transaction that does nothing.
  if (staking.certificates !== undefined && staking.certificates.length > 0) {
    entries.push([uint(4), encodeCertificates(staking.certificates)]);
  }
  if (staking.withdrawals !== undefined && staking.withdrawals.length > 0) {
    entries.push([uint(5), encodeWithdrawals(staking.withdrawals)]);
  }

  return map(entries);
}

/**
 * Serializes a `transaction_body` that carries certificates, withdrawals, or neither.
 *
 * Exported so the staking side can build and inspect a body without going through coin selection,
 * which is what makes the encoding testable against an independent CBOR implementation before any
 * of it is wired to money.
 *
 * @param inputs - Outputs being spent.
 * @param outputs - Already-serialized outputs, in order.
 * @param fee - Fee in lovelace.
 * @param ttlSlot - Slot after which the transaction is no longer valid.
 * @param staking - Certificates and withdrawals, both optional.
 * @returns The canonical CBOR of the body.
 */
export function encodeTransactionBody(
  inputs: readonly CardanoUtxo[],
  outputs: readonly Uint8Array[],
  fee: bigint,
  ttlSlot: number,
  staking: CardanoStakingBodyFields = {}
): Uint8Array {
  return encodeBody(inputs, outputs, fee, ttlSlot, staking);
}

/**
 * The transaction id of a body: its blake2b-256 hash.
 *
 * @param bodyBytes - Serialized `transaction_body`.
 * @returns The transaction id, hex without `0x`.
 */
export function transactionIdOf(bodyBytes: Uint8Array): string {
  return bytesToHex(blake2b(bodyBytes, { dkLen: TX_ID_BYTES }));
}

/**
 * Assembles the signed transaction a provider accepts.
 *
 * @param bodyBytes - The serialized body the witnesses signed. Reused verbatim rather than
 *   re-encoded, so the submitted transaction cannot differ from the one that was hashed and signed.
 * @param witnesses - One entry per distinct signing key.
 * @returns The serialized signed transaction, hex without `0x`.
 * @throws Error `CARDANO_WITNESS_REQUIRED` when no witness is supplied: an unsigned transaction is
 *   not a transaction anyone can submit, and returning one would defer the failure to the provider.
 */
export function encodeSignedTransaction(
  bodyBytes: Uint8Array,
  witnesses: readonly CardanoVkeyWitness[]
): string {
  if (witnesses.length === 0) throw new Error('CARDANO_WITNESS_REQUIRED');
  const witnessSet = map([
    [
      uint(0),
      set(
        witnesses.map((witness) =>
          array([bytes(hexToBytes(witness.publicKey)), bytes(hexToBytes(witness.signature))])
        )
      )
    ]
  ]);
  return bytesToHex(array([bodyBytes, witnessSet, CBOR_TRUE, CBOR_NULL]));
}

/**
 * The fee a transaction of this size pays, per the protocol parameters.
 *
 * @param sizeBytes - Size of the **signed** transaction. The witnesses are part of what the network
 *   charges for, so a fee computed over the body alone is short by about a hundred bytes.
 * @param parameters - Protocol parameters in force.
 * @returns The fee in lovelace.
 */
function feeForSize(sizeBytes: number, parameters: CardanoProtocolParameters): bigint {
  return BigInt(parameters.minFeeA) * BigInt(sizeBytes) + BigInt(parameters.minFeeB);
}

/** Largest first, then by outpoint, so two identical calls select identically. */
function byLovelaceThenOutpoint(left: CardanoUtxo, right: CardanoUtxo): number {
  if (left.lovelace !== right.lovelace) return left.lovelace > right.lovelace ? -1 : 1;
  const byHash = left.txHash.localeCompare(right.txHash);
  return byHash !== 0 ? byHash : left.outputIndex - right.outputIndex;
}

/**
 * What the **sponsor** can spend, ADA-only outputs first.
 *
 * This used to exclude outputs carrying tokens outright, and the reason was sound: a sponsor input
 * holding tokens would drag them into a change output belonging to the *sender*, which is how a
 * sponsor quietly gives its assets away. What was missed is that the sponsor has a change output of
 * its own, and returning them there costs nothing but the bytes.
 *
 * Excluding them was not a small conservatism. ChatterPay's fee on a token transfer rides home in
 * the sponsor's change, which makes that output token-bearing — so under the old filter **every
 * token transfer permanently retired one of the sponsor's outputs**, and a wallet funded with a
 * single large output was one transfer away from reporting itself empty while holding thousands of
 * ADA. Observed on Preprod: 9794 ADA held, 3.64 spendable.
 *
 * ADA-only still comes first. Reaching for a token-bearing output grows the transaction, so it is a
 * last resort rather than a refusal.
 *
 * @param utxos - Everything the address holds.
 * @returns All of them, ADA-only first and each group ordered by descending value and then by
 *   outpoint, so that equal values do not select in provider order — a selection that changes
 *   between two identical calls is a fee that changes for no reason.
 */
export function spendableUtxos(utxos: readonly CardanoUtxo[]): CardanoUtxo[] {
  const plain = utxos.filter((utxo) => !utxo.holdsOtherAssets).sort(byLovelaceThenOutpoint);
  const bearing = utxos.filter((utxo) => utxo.holdsOtherAssets).sort(byLovelaceThenOutpoint);
  return [...plain, ...bearing];
}

/**
 * What the sponsor can spend right now.
 *
 * @param utxos - Everything the address holds.
 * @returns Spendable lovelace, tokens' company included.
 */
export function spendableBalance(utxos: readonly CardanoUtxo[]): bigint {
  return spendableUtxos(utxos).reduce((sum, utxo) => sum + utxo.lovelace, 0n);
}

/**
 * Lovelace held in outputs that carry nothing else.
 *
 * A reporting figure, not a selection one: it answers "how much of this balance is not sitting
 * beside a token", which is what a wallet view means by ADA that is spoken for. Kept apart from
 * {@link spendableBalance} because that one answers a different question — what the builder may
 * reach for — and the two stopped having the same answer once the sponsor learned to spend its own
 * token-bearing outputs.
 *
 * @param utxos - Everything the address holds.
 * @returns Lovelace in ADA-only outputs.
 */
export function adaOnlyBalance(utxos: readonly CardanoUtxo[]): bigint {
  return utxos
    .filter((utxo) => !utxo.holdsOtherAssets)
    .reduce((sum, utxo) => sum + utxo.lovelace, 0n);
}

/**
 * Everything the **sender** can reach, in the order it should be reached for.
 *
 * ADA-only outputs come first because they add no bytes beyond the input itself. Outputs holding
 * tokens come after: pulling one in drags its assets into the change output and grows the
 * transaction, so it is a last resort — but only a last resort, not a refusal. Excluding them
 * outright, which is what this used to do, stranded the ADA beside every token a wallet held: a
 * wallet whose whole balance had landed in one token-bearing output could not send ADA at all, and
 * the balance it was shown had that ADA missing from it.
 *
 * @param utxos - Everything the address holds.
 * @returns Every output, ADA-only ones first, each group largest first.
 */
export function selectableUtxos(utxos: readonly CardanoUtxo[]): CardanoUtxo[] {
  return [
    ...utxos.filter((utxo) => !utxo.holdsOtherAssets).sort(byLovelaceThenOutpoint),
    ...utxos.filter((utxo) => utxo.holdsOtherAssets).sort(byLovelaceThenOutpoint)
  ];
}

/**
 * Every lovelace the sender holds, tokens' company included.
 *
 * Not quite all of it is reachable: when the wallet holds tokens, the change output that carries
 * them has to keep its own min-ADA, so roughly one min-ADA of this figure can never leave. That
 * correction belongs to whoever knows the protocol parameters — the builder refuses precisely, and
 * `adaTransferRequirement` explains it — and not to a balance.
 *
 * @param utxos - Everything the address holds.
 * @returns Total lovelace.
 */
export function selectableBalance(utxos: readonly CardanoUtxo[]): bigint {
  return utxos.reduce((sum, utxo) => sum + utxo.lovelace, 0n);
}

/** The native assets an output holds, normalised to lowercase hex. */
function assetsOf(utxo: CardanoUtxo): CardanoAssetAmount[] {
  return (utxo.assets ?? []).map((asset) => ({
    policyId: asset.policyId.toLowerCase(),
    assetName: asset.assetName.toLowerCase(),
    quantity: asset.quantity
  }));
}

/** A stable key for an unspent output. */
function outpointOf(utxo: CardanoUtxo): string {
  return `${utxo.txHash}#${utxo.outputIndex}`;
}

/**
 * How much of one asset an output holds.
 *
 * @param utxo - The output.
 * @param asset - The asset being counted.
 * @returns The quantity, `0n` when the output does not hold it.
 */
function quantityOf(utxo: CardanoUtxo, asset: CardanoAsset): bigint {
  const unit = assetUnit(asset);
  return assetsOf(utxo)
    .filter((held) => assetUnit(held) === unit)
    .reduce((sum, held) => sum + held.quantity, 0n);
}

/**
 * How much of one asset a wallet holds in total.
 *
 * @param utxos - Everything the address holds.
 * @param asset - The asset being counted.
 * @returns The quantity across every output.
 */
export function assetBalance(utxos: readonly CardanoUtxo[], asset: CardanoAsset): bigint {
  return utxos.reduce((sum, utxo) => sum + quantityOf(utxo, asset), 0n);
}

/**
 * Every native asset a wallet holds, summed per asset.
 *
 * @param utxos - Outputs to total.
 * @returns One entry per distinct asset, in canonical key order.
 */
export function totalAssets(utxos: readonly CardanoUtxo[]): CardanoAssetAmount[] {
  const totals = new Map<string, CardanoAssetAmount>();
  for (const utxo of utxos) {
    for (const asset of assetsOf(utxo)) {
      const unit = assetUnit(asset);
      const current = totals.get(unit);
      totals.set(
        unit,
        current ? { ...current, quantity: current.quantity + asset.quantity } : { ...asset }
      );
    }
  }
  return [...totals.values()].sort((left, right) =>
    compareCborKeys(assetUnit(left), assetUnit(right))
  );
}

/**
 * How many of the destination's outputs one transfer will fold in.
 *
 * The saving is almost all in the first one — after that the floor has already been funded and each
 * extra input only adds bytes. Uncapped it is worse than pointless: a destination holding a few
 * hundred outputs of a token produces a transaction over `maxTxSize`, and since nothing falls back
 * to not recycling, **every transfer of that token to them fails from then on**. Addresses are
 * public and small outputs are cheap to create, so that is reachable from outside.
 */
const MAX_RECYCLED_OUTPUTS = 5;

/**
 * The destination's outputs that may be folded into the one a transfer creates.
 *
 * Only those holding exactly this token and nothing else: an output carrying a second asset would
 * drag it into the new output. It would go back to its own owner, so nothing is lost, but it
 * changes that output's floor and it is not this transfer's business to move.
 *
 * Exported because the transfer service asks the same question before the build — to decide the
 * fee and how many signatures to expect — and two copies of this rule is how the two answers come
 * to disagree.
 *
 * @param utxos - Everything the destination holds.
 * @param asset - The token being sent.
 * @param limit - Ceiling on how many to take, largest first.
 * @returns The outputs safe to recycle, which is often none.
 */
export function recyclableOutputs(
  utxos: readonly CardanoUtxo[],
  asset: CardanoAsset,
  limit: number = MAX_RECYCLED_OUTPUTS
): CardanoUtxo[] {
  const policyId = asset.policyId.toLowerCase();
  const assetName = asset.assetName.toLowerCase();
  return utxos
    .filter((utxo) => {
      const assets = utxo.assets ?? [];
      return (
        assets.length === 1 &&
        assets[0].policyId.toLowerCase() === policyId &&
        assets[0].assetName.toLowerCase() === assetName
      );
    })
    .sort(byLovelaceThenOutpoint)
    .slice(0, limit);
}

/**
 * Chooses the sponsor's inputs, and the floor its own change output has to clear.
 *
 * The two are circular: what the sponsor's change must hold depends on the tokens it carries home,
 * and which tokens those are depends on which inputs were chosen. Solving it in one pass — pricing
 * the floor as if the change were pure ADA — under-selects the moment the sponsor holds anything
 * but ADA, and then refuses a transfer it could plainly afford. So it converges instead: price,
 * select, re-price, and stop when the floor stops rising.
 *
 * @param available - The sponsor's outputs, in selection order.
 * @param need - Lovelace the sponsor has to cover beyond its own change: the network fee, plus any
 *   min-ADA it is supplying.
 * @param changeAddress - Where its change returns.
 * @param extraChangeAssets - Assets that will ride in that change without having come from these
 *   inputs, which is ChatterPay's fee on a token transfer.
 * @param needsChange - Whether the change output has to exist even holding no tokens, which is the
 *   case when the sender's routed remainder is riding in it.
 * @param coinsPerUtxoByte - Protocol parameter.
 * @returns The chosen inputs and the assets of theirs that must come home.
 * @throws Error `CARDANO_SPONSOR_FLOOR_DID_NOT_CONVERGE` when the loop fails to settle, which is a
 *   defect rather than a wallet being short.
 */
function selectSponsorInputs(
  available: readonly CardanoUtxo[],
  need: bigint,
  changeAddress: Uint8Array,
  extraChangeAssets: readonly CardanoAssetAmount[],
  needsChange: boolean,
  coinsPerUtxoByte: bigint
): { selected: CardanoUtxo[]; residual: CardanoAssetAmount[] } {
  const floorFor = (assets: readonly CardanoAssetAmount[]): bigint =>
    assets.length > 0 || needsChange ? minimumAdaFor(changeAddress, assets, coinsPerUtxoByte) : 0n;

  let floor = floorFor(extraChangeAssets);
  for (let pass = 0; pass < MAX_FEE_PASSES; pass++) {
    const selected = selectFor(available, need + floor);
    const residual = totalAssets(selected);
    const next = floorFor(mergeAssets(residual, extraChangeAssets));
    if (next <= floor) return { selected, residual };
    floor = next;
  }
  throw new Error('CARDANO_SPONSOR_FLOOR_DID_NOT_CONVERGE');
}

/**
 * Several asset lists as one, quantities of the same asset added together.
 *
 * The encoder already sums duplicates, so a list holding the same asset twice serializes correctly
 * either way. What it does not do is fix the list, and that list is reported to the caller and
 * written into the pending-change record — where anything reading `.length` or `[0].quantity` gets
 * a wrong answer from a right transaction.
 *
 * @param lists - The lists to merge.
 * @returns One list, in canonical order, with no asset appearing twice.
 */
export function mergeAssets(
  ...lists: readonly (readonly CardanoAssetAmount[])[]
): CardanoAssetAmount[] {
  const totals = new Map<string, CardanoAssetAmount>();
  for (const asset of lists.flat()) {
    if (asset.quantity <= 0n) continue;
    const unit = assetUnit(asset);
    const current = totals.get(unit);
    totals.set(
      unit,
      current ? { ...current, quantity: current.quantity + asset.quantity } : { ...asset }
    );
  }
  return [...totals.values()].sort((left, right) =>
    compareCborKeys(assetUnit(left), assetUnit(right))
  );
}

/**
 * Outputs holding a given asset, most of it first.
 *
 * Largest-first over the *asset* rather than over ADA: covering the quantity in as few inputs as
 * possible is what keeps the transaction small, and the transaction size is the fee.
 *
 * @param utxos - Everything the address holds.
 * @param asset - The asset being spent.
 * @returns The outputs that hold it, ordered deterministically.
 */
export function utxosHolding(utxos: readonly CardanoUtxo[], asset: CardanoAsset): CardanoUtxo[] {
  return utxos
    .filter((utxo) => quantityOf(utxo, asset) > 0n)
    .slice()
    .sort((left, right) => {
      const byQuantity = quantityOf(right, asset) - quantityOf(left, asset);
      if (byQuantity !== 0n) return byQuantity > 0n ? 1 : -1;
      return outpointOf(left).localeCompare(outpointOf(right));
    });
}

/**
 * The smallest lovelace an output holding these assets may carry.
 *
 * Iterated rather than computed in one shot: the minimum depends on the output's serialized size,
 * and the size depends on how many bytes the lovelace figure itself takes. Two or three passes.
 *
 * @param addressBytes - Address the output pays.
 * @param assets - Assets the output carries.
 * @param coinsPerUtxoByte - Protocol parameter.
 * @returns The minimum, in lovelace.
 * @throws Error `CARDANO_MIN_ADA_DID_NOT_CONVERGE` when the loop fails to settle.
 */
export function minimumAdaFor(
  addressBytes: Uint8Array,
  assets: readonly CardanoAssetAmount[],
  coinsPerUtxoByte: bigint
): bigint {
  let value = minimumAdaForOutput(encodeOutput(addressBytes, 0n, assets), coinsPerUtxoByte);
  for (let pass = 0; pass < 4; pass++) {
    const required = minimumAdaForOutput(
      encodeOutput(addressBytes, value, assets),
      coinsPerUtxoByte
    );
    if (required <= value) return value;
    value = required;
  }
  throw new Error('CARDANO_MIN_ADA_DID_NOT_CONVERGE');
}

/** What is left of the inputs' assets after sending one of them. */
function residualAssets(
  selected: readonly CardanoUtxo[],
  sent: CardanoAssetAmount
): CardanoAssetAmount[] {
  const sentUnit = assetUnit(sent);
  return totalAssets(selected)
    .map((held) =>
      assetUnit(held) === sentUnit ? { ...held, quantity: held.quantity - sent.quantity } : held
    )
    .filter((held) => held.quantity > 0n);
}

/**
 * Takes UTxOs off the front of an already-ordered list until they cover `target`.
 *
 * @param available - Spendable outputs, largest first.
 * @param target - Amount plus fee that has to be covered.
 * @returns The selected outputs.
 * @throws Error `CARDANO_INSUFFICIENT_FUNDS` when everything spendable is not enough.
 */
/**
 * What the selection below would actually gather for a target.
 *
 * Exported because the pre-flight has to answer the same question this builder answers, and
 * answering it against the *balance* instead of against the *selection* is how a transfer gets
 * approved and then burns the remainder: coin selection stops as soon as it covers the target, so
 * the change is whatever the chosen outputs leave over, not whatever the wallet holds.
 *
 * @param utxos - Everything the address holds.
 * @param target - Lovelace the selection has to cover.
 * @returns The outputs the selection gathers, or `null` when they cannot reach the target.
 */
export function selectionFor(utxos: readonly CardanoUtxo[], target: bigint): CardanoUtxo[] | null {
  const selected: CardanoUtxo[] = [];
  let total = 0n;
  for (const utxo of selectableUtxos(utxos)) {
    selected.push(utxo);
    total += utxo.lovelace;
    if (total >= target) return selected;
  }
  return null;
}

/**
 * The lovelace {@link selectionFor} would gather.
 *
 * @param utxos - Everything the address holds.
 * @param target - Lovelace the selection has to cover.
 * @returns The total gathered, or `null` when the target cannot be reached.
 */
export function selectionTotalFor(utxos: readonly CardanoUtxo[], target: bigint): bigint | null {
  const selected = selectionFor(utxos, target);
  return selected ? selected.reduce((sum, utxo) => sum + utxo.lovelace, 0n) : null;
}

function selectFor(available: readonly CardanoUtxo[], target: bigint): CardanoUtxo[] {
  const selected: CardanoUtxo[] = [];
  let total = 0n;
  for (const utxo of available) {
    selected.push(utxo);
    total += utxo.lovelace;
    if (total >= target) return selected;
  }
  throw new Error(`CARDANO_INSUFFICIENT_FUNDS: have ${total} lovelace, need ${target}`);
}

/**
 * Builds a transfer: selects inputs, computes the exact fee, and places the change.
 *
 * The fee depends on the size, the size depends on the fee and the change, and the change depends
 * on the fee — so this iterates until the fee stops rising rather than padding an estimate. What
 * comes out is exact: the fee in the body is the fee the network charges for those bytes.
 *
 * Change below the minimum a UTxO may hold cannot be returned as an output and is added to the fee
 * instead. That is a real cost to the sender and it is reported as fee rather than hidden, which is
 * what lets reconciliation add up: inputs = amount + fee + change, always.
 *
 * **ChatterPay's fee comes out of the amount, not out of the sender's pocket.** The destination
 * receives `amount − fee` and the fee rides in the sponsor's change output, which already exists in
 * every sponsored transfer and sits far above the floor an output must clear. Nothing accrues,
 * nothing is deferred, and every transfer charges the same figure — the deferral only ever existed
 * because a fee in its own output could not clear min-ADA.
 *
 * @param plan - Inputs, addresses, amount, expiry and parameters.
 * @returns The body, its transaction id, and the numbers the ledger reconciles against.
 * @throws Error `CARDANO_AMOUNT_BELOW_MINIMUM_UTXO` when what would reach the destination — the
 *   amount less ChatterPay's fee — is under the min-ADA of the output carrying it. The network
 *   would reject the transaction, so it is refused before anything is signed.
 * @throws Error `CARDANO_INSUFFICIENT_FUNDS` when the spendable UTxOs do not cover amount plus fee.
 *   Raised before signing on purpose: a transaction that cannot pay its own fee has no partial
 *   outcome to recover from.
 * @throws Error `CARDANO_TX_TOO_LARGE` when the transaction exceeds `maxTxSize`, which is what a
 *   wallet fragmented into many small UTxOs eventually produces.
 * @throws Error `CARDANO_FEE_DID_NOT_CONVERGE` when the fee loop fails to settle.
 */
export function buildCardanoTransfer(plan: CardanoTransferPlan): BuiltCardanoTransaction {
  return plan.asset ? buildAssetTransfer(plan, plan.asset) : buildAdaTransfer(plan);
}

/**
 * Builds a plain ADA transfer.
 *
 * @param plan - Inputs, addresses, amount, expiry and parameters.
 * @returns The body, its transaction id, and the numbers the ledger reconciles against.
 */
function buildAdaTransfer(plan: CardanoTransferPlan): BuiltCardanoTransaction {
  const { parameters, amount, ttlSlot } = plan;

  // ChatterPay's fee comes out of the amount, so the destination's output is what is left of it.
  // Without a sponsor there is no change output to fold the fee into and nothing is charged.
  const chatterPayFee = plan.sponsor ? (plan.chatterPayFee ?? 0n) : 0n;
  if (chatterPayFee < 0n || chatterPayFee >= amount) {
    throw new Error(`CARDANO_INVALID_FEE: ${chatterPayFee} against an amount of ${amount}`);
  }
  const delivered = amount - chatterPayFee;

  const paymentOutput = encodeOutput(plan.destinationAddress, delivered);
  const minimumPayment = minimumAdaForOutput(paymentOutput, parameters.coinsPerUtxoByte);
  if (delivered < minimumPayment) {
    // Stated against the amount rather than against what is left of it: the caller asked to send
    // `amount`, and the number they need to hear is the smallest amount that would work.
    throw new Error(
      `CARDANO_AMOUNT_BELOW_MINIMUM_UTXO: ${minimumPayment + chatterPayFee} lovelace minimum`
    );
  }

  const available = selectableUtxos(plan.utxos);
  const placeholderWitnesses = Array.from({ length: Math.max(1, plan.witnessCount) }, () => ({
    publicKey: '00'.repeat(PUBLIC_KEY_BYTES),
    signature: '00'.repeat(SIGNATURE_BYTES)
  }));
  const signedSizeOf = (body: Uint8Array): number =>
    encodeSignedTransaction(body, placeholderWitnesses).length / 2;

  const sponsor = plan.sponsor;
  const sponsorAvailable = sponsor ? spendableUtxos(sponsor.utxos) : [];

  // Routing needs somewhere to route to, so it is a sponsor's capability and reads as one here
  // rather than being checked at each of the three places below.
  const routeDust = sponsor !== undefined && plan.routeDustToSponsor === true;

  // The sender covers the amount, and only the amount: what the destination gets plus the fee that
  // joins the sponsor's change are the two halves of it. The sponsor covers the network fee.
  const senderOwes = amount;

  let fee = feeForSize(0, parameters);
  for (let pass = 0; pass < MAX_FEE_PASSES; pass++) {
    const target = sponsor ? senderOwes : senderOwes + fee;
    let selected = selectFor(available, target);
    let total = selected.reduce((sum, utxo) => sum + utxo.lovelace, 0n);
    let change = total - target;
    // Sender lovelace that ends up in the sponsor's change output because it was too small to be an
    // output of its own. The money still left the sender, so it is tracked rather than dropped: the
    // caller credits it back off-chain.
    let routed = 0n;
    // Tokens carried by the outputs that were selected. Nothing is being sent of them, so all of it
    // comes back — and unlike dust ADA it can never be folded into the fee: a transaction that does
    // not return its inputs' assets does not balance and the ledger rejects it.
    let residual = totalAssets(selected);

    // Change below the floor is change the network takes as fee: the transfer succeeds and the
    // sender is quietly short by up to a whole min-ADA. Coin selection stops as soon as it covers
    // the target, so this is not a matter of the wallet being poor — it is one output's remainder
    // landing in the gap. Pulling one more output is what a wallet does about it, and it is only
    // when there is nothing left to pull that the transfer has to be refused.
    //
    // Repeated rather than corrected once, because the output pulled in may itself carry tokens:
    // they join the change, the change grows by their bytes, and its floor rises again. Every pass
    // adds at least one input — `change < floor` is the same statement as `total < target + floor`
    // — so this ends, at the latest when the wallet runs out.
    for (;;) {
      const floor = minimumAdaForOutput(
        encodeOutput(plan.changeAddress, change, residual),
        parameters.coinsPerUtxoByte
      );
      // No change and no tokens to bring home is the one case needing no change output at all.
      if (change >= floor || (change === 0n && residual.length === 0)) break;
      let widened: CardanoUtxo[];
      try {
        widened = selectFor(available, target + floor);
      } catch {
        // Nothing further to pull in. Routing the remainder to the sponsor is what turns this from
        // a refusal into a transfer: the ledger only asks that the transaction balance, and an
        // input of the sender's may pay an output of the sponsor's. The sender is credited for it
        // off-chain, so the money is theirs either way — it just travels through ChatterPay's
        // address rather than sitting in an output the network will not accept.
        //
        // Only when the remainder carries no tokens. Residual assets have to come home: routing
        // them would be taking the sender's token, which is the one thing this must never do.
        if (routeDust && residual.length === 0) {
          routed = change;
          change = 0n;
          break;
        }
        throw new Error(
          `CARDANO_CHANGE_WOULD_BE_BURNED: ${change} lovelace of change is below the ${floor} ` +
            `an output must hold${residual.length > 0 ? ` while carrying ${residual.length} token(s) home` : ''}, ` +
            `and there is nothing further to select`
        );
      }
      selected = widened;
      total = selected.reduce((sum, utxo) => sum + utxo.lovelace, 0n);
      change = total - target;
      residual = totalAssets(selected);
    }

    // The sponsor covers the network fee — and, when a ChatterPay fee is riding home with it, has
    // to end up with a change output that can actually stand. An output below the floor is one the
    // network keeps, and the fee would go to the chain instead of to ChatterPay while the
    // destination had already been docked for it. Selecting for the floor as well is what rules
    // that out, rather than discovering it after the fact.
    // ChatterPay's fee is lovelace on this path, so it folds into the change's value rather than
    // riding in it as an asset: there is nothing extra for the floor to account for beyond whatever
    // the sponsor's own inputs bring home.
    const sponsorChoice = sponsor
      ? selectSponsorInputs(
          sponsorAvailable,
          fee,
          sponsor.changeAddress,
          [],
          chatterPayFee > 0n || routed > 0n,
          parameters.coinsPerUtxoByte
        )
      : { selected: [] as CardanoUtxo[], residual: [] as CardanoAssetAmount[] };
    const sponsorSelected = sponsorChoice.selected;
    const sponsorTotal = sponsorSelected.reduce((sum, utxo) => sum + utxo.lovelace, 0n);
    // Whatever the sponsor's own inputs carried. It goes back to the sponsor, and it has to: a
    // transaction that does not return its inputs' assets does not balance.
    const sponsorResidual = sponsorChoice.residual;

    const changeOutput = encodeOutput(plan.changeAddress, change, residual);
    const keepsChange =
      change > 0n && change >= minimumAdaForOutput(changeOutput, parameters.coinsPerUtxoByte);
    if (!keepsChange && (change > 0n || residual.length > 0)) {
      throw new Error(
        `CARDANO_CHANGE_WOULD_BE_BURNED: ${change} lovelace is below the minimum an output may hold`
      );
    }
    if (!keepsChange) change = 0n;

    // ChatterPay's fee folds in here, and this is the whole trick: no new output, so no min-ADA to
    // clear, so no reason to defer the fee until it has grown past one. Routed change folds into the
    // same output for the same reason, and is the one part of it that is owed back to the sender.
    let sponsorChange = sponsor ? sponsorTotal - fee + chatterPayFee + routed : 0n;
    const sponsorChangeOutput = sponsor
      ? encodeOutput(sponsor.changeAddress, sponsorChange, sponsorResidual)
      : new Uint8Array();
    const keepsSponsorChange =
      sponsor !== undefined &&
      sponsorChange > 0n &&
      sponsorChange >= minimumAdaForOutput(sponsorChangeOutput, parameters.coinsPerUtxoByte);
    // Dropping the sponsor's leftover into the fee is a call the sponsor gets to make about its own
    // money. It is not a call anybody gets to make about the sender's: routed change that cannot
    // stand as an output would be the sender paying for the privilege of being refused politely.
    if (!keepsSponsorChange && routed > 0n) {
      throw new Error(
        `CARDANO_ROUTED_CHANGE_WOULD_BE_BURNED: ${routed} lovelace of the sender's change was ` +
          `routed to the sponsor, whose own change of ${sponsorChange} cannot stand as an output`
      );
    }
    // Dropping the sponsor's leftover into the fee is a decision about lovelace. Tokens have no
    // such escape: a body that does not return them does not balance and the chain rejects it.
    if (!keepsSponsorChange && sponsorResidual.length > 0) {
      throw new Error(
        `CARDANO_SPONSOR_CHANGE_WOULD_BE_BURNED: ${sponsorChange} lovelace cannot stand as an ` +
          `output while carrying ${sponsorResidual.length} token(s) home`
      );
    }
    if (!keepsSponsorChange) sponsorChange = 0n;

    const outputs = [
      paymentOutput,
      ...(keepsChange ? [changeOutput] : []),
      ...(keepsSponsorChange ? [sponsorChangeOutput] : [])
    ];
    const inputs = [...selected, ...sponsorSelected];
    const body = encodeBody(
      inputs,
      outputs,
      total + sponsorTotal - delivered - change - sponsorChange,
      ttlSlot
    );
    const size = signedSizeOf(body);
    if (size > parameters.maxTxSize) {
      throw new Error(`CARDANO_TX_TOO_LARGE: ${size} bytes over ${parameters.maxTxSize}`);
    }

    const required = feeForSize(size, parameters);
    if (required <= fee) {
      return {
        bodyBytes: body,
        changeIndex: keepsChange ? 1 : undefined,
        sponsorChangeIndex: keepsSponsorChange ? outputs.length - 1 : undefined,
        transactionId: transactionIdOf(body),
        fee: total + sponsorTotal - delivered - change - sponsorChange,
        sentLovelace: delivered,
        change,
        changeAssets: keepsChange ? residual : [],
        inputs,
        ttlSlot,
        chatterPayFee,
        routedToSponsor: routed,
        sponsorChangeAssets: keepsSponsorChange ? sponsorResidual : [],
        // Nothing on the ADA path: the min-ADA of the destination's output comes out of the amount
        // the sender asked to send, so there is no output here for the sponsor to fund — and
        // nothing of the destination's to fold into it either.
        sponsorSuppliedLovelace: 0n,
        recycledLovelace: 0n
      };
    }
    fee = required;
  }

  throw new Error('CARDANO_FEE_DID_NOT_CONVERGE');
}

/**
 * Builds a native-asset transfer.
 *
 * Three things make this different from the ADA path, and all three are consequences of the same
 * rule — a Cardano output carries a *value*, and a token cannot travel without ADA beside it:
 *
 * 1. **The token output must carry ADA.** The minimum is set by the output's own size, and for a
 *    token output it lands around 1.2–1.5 ADA. That ADA leaves the sender and arrives at the
 *    recipient; it is not a fee, and it is not optional.
 * 2. **Residual tokens must come back.** Spending an output holding 100 USDM to send 30 requires a
 *    change output carrying 70. Unlike dust ADA, residual tokens can never be folded into the fee:
 *    a transaction that does not return them does not balance and the ledger rejects it. So when
 *    there are residuals the change output is mandatory, and if the selected inputs cannot fund its
 *    min-ADA, more ADA has to be pulled in.
 * 3. **Selection is two-dimensional.** Inputs must cover the token quantity *and* enough ADA for
 *    the token output, the fee and the change. Covering one says nothing about the other.
 *
 * @param plan - Inputs, addresses, expiry and parameters.
 * @param asset - The asset and quantity being sent.
 * @returns The body, its transaction id, and the numbers the ledger reconciles against.
 * @throws Error `CARDANO_INVALID_ASSET_QUANTITY` for a non-positive quantity.
 * @throws Error `CARDANO_INSUFFICIENT_TOKEN_BALANCE` when the wallet does not hold enough of it.
 * @throws Error `CARDANO_INSUFFICIENT_FUNDS` when there is not enough ADA to carry the transfer —
 *   which is the state a wallet holding stablecoins and no ADA is permanently in.
 * @throws Error `CARDANO_TX_TOO_LARGE`, `CARDANO_FEE_DID_NOT_CONVERGE` as in the ADA path.
 */
function buildAssetTransfer(
  plan: CardanoTransferPlan,
  asset: CardanoAssetAmount
): BuiltCardanoTransaction {
  const { parameters, ttlSlot } = plan;
  if (asset.quantity <= 0n) throw new Error('CARDANO_INVALID_ASSET_QUANTITY');

  const sent: CardanoAssetAmount = {
    policyId: asset.policyId.toLowerCase(),
    assetName: asset.assetName.toLowerCase(),
    quantity: asset.quantity
  };

  // Inputs that carry the token, fewest first. Refused here rather than after a signature.
  const holders = utxosHolding(plan.utxos, sent);
  const assetInputs: CardanoUtxo[] = [];
  let held = 0n;
  for (const utxo of holders) {
    assetInputs.push(utxo);
    held += quantityOf(utxo, sent);
    if (held >= sent.quantity) break;
  }
  if (held < sent.quantity) {
    throw new Error(`CARDANO_INSUFFICIENT_TOKEN_BALANCE: have ${held}, need ${sent.quantity}`);
  }

  // Outputs available to top the transaction up, in the order they should be reached for.
  //
  // Pure-ADA ones come first because they add no bytes beyond the input itself. Outputs holding
  // *other* tokens come after: pulling one in drags its assets into the change output and grows the
  // transaction, but a wallet holding several stablecoins and no loose ADA has nothing else — and
  // refusing it would be refusing a transfer the wallet can plainly afford.
  const alreadyChosen = new Set(assetInputs.map(outpointOf));
  const spare = selectableUtxos(plan.utxos.filter((utxo) => !alreadyChosen.has(outpointOf(utxo))));

  // Sponsoring works here exactly as it does on the ADA path: a second wallet contributes inputs
  // that cover the network fee and gets its own change back. Only its ADA-only outputs are taken —
  // pulling in a sponsor UTxO that holds tokens would drag them into a change output belonging to
  // the sender, which is how a sponsor quietly gives its assets away.
  const sponsor = plan.sponsor;
  const sponsorAvailable = sponsor ? spendableUtxos(sponsor.utxos) : [];

  // The two capabilities scheme 2 turns on, both of them things only a sponsor can do.
  //
  // `sponsorMinAda` is the one that matters here. Off, the ADA riding with the token comes out of
  // the sender's inputs and their ADA balance falls by roughly 1.16 on every token transfer, which
  // is the figure a user sees leave their wallet and reads as a charge. On, the sponsor's inputs
  // cover it: the sender spends token and nothing else.
  const sponsorMinAda = sponsor !== undefined && plan.sponsorMinAda === true;
  const routeDust = sponsor !== undefined && plan.routeDustToSponsor === true;

  const placeholderWitnesses = Array.from({ length: Math.max(1, plan.witnessCount) }, () => ({
    publicKey: '00'.repeat(PUBLIC_KEY_BYTES),
    signature: '00'.repeat(SIGNATURE_BYTES)
  }));
  const signedSizeOf = (body: Uint8Array): number =>
    encodeSignedTransaction(body, placeholderWitnesses).length / 2;

  // ChatterPay's fee is charged in whatever is moving, so on a token transfer it is token units and
  // not lovelace — the same thing EVM does, where the fee comes out of the token being sent. It
  // rides in the sponsor's change output, which costs no extra ADA: that output already exists and
  // an output carries a value, so adding a token to it adds bytes and nothing else.
  const chatterPayFee = sponsor ? (plan.chatterPayFee ?? 0n) : 0n;
  if (chatterPayFee < 0n || chatterPayFee >= sent.quantity) {
    throw new Error(`CARDANO_INVALID_FEE: ${chatterPayFee} against a quantity of ${sent.quantity}`);
  }
  // What the destination gets. The whole of `sent` still leaves the sender — part to the
  // destination, part to the sponsor — which is why the residual is still measured against `sent`.
  const delivered: CardanoAssetAmount = { ...sent, quantity: sent.quantity - chatterPayFee };
  const feeAsset: CardanoAssetAmount = { ...sent, quantity: chatterPayFee };

  // Outputs of the destination's own, folded into the one this transfer creates. Only those whose
  // sole asset is this token: anything else is not this transfer's to move, and it would change the
  // floor of an output somebody else has to live with.
  const recycled = recyclableOutputs(plan.recycleUtxos ?? [], sent);
  const recycledLovelace = recycled.reduce((sum, utxo) => sum + utxo.lovelace, 0n);
  const recycledQuantity = recycled.reduce((sum, utxo) => sum + quantityOf(utxo, sent), 0n);

  // What the destination's single output ends up holding: what is being sent them plus what they
  // already had. Same asset, so still one entry, and an output with more of one token is a couple
  // of bytes larger at most — which is the whole reason this costs nothing.
  const destinationHolds: CardanoAssetAmount = {
    ...sent,
    quantity: delivered.quantity + recycledQuantity
  };

  // The ADA attached to the token output: what the caller asked for, or the protocol minimum — but
  // never less than what the recycled outputs already carried. Handing back less than they came
  // with would be taking ADA off the recipient to pay for their own consolidation.
  const minimumAttached = minimumAdaFor(
    plan.destinationAddress,
    [destinationHolds],
    parameters.coinsPerUtxoByte
  );
  const requestedAttached = plan.amount > 0n ? plan.amount : minimumAttached;
  const attached = recycledLovelace > requestedAttached ? recycledLovelace : requestedAttached;
  if (attached < minimumAttached) {
    throw new Error(`CARDANO_AMOUNT_BELOW_MINIMUM_UTXO: ${minimumAttached} lovelace minimum`);
  }
  const paymentOutput = encodeOutput(plan.destinationAddress, attached, [destinationHolds]);

  // Carrying a token raises the floor of the sponsor's change output, so its inputs have to cover
  // the network fee *and* that floor — see the note on the ADA path. Under scheme 2 they also have
  // to cover the ADA attached to the token output, which is the sponsor's to supply.
  // What the sponsor has to put in: the attached ADA less whatever the recycled outputs already
  // carried. When the destination already held this token, that difference is zero — which is the
  // entire economics of recycling, and the reason the ordinary fee can stay small.
  const attachedShortfall = attached > recycledLovelace ? attached - recycledLovelace : 0n;
  const sponsorSupplies = sponsorMinAda ? attachedShortfall : 0n;

  // One pass per extra ADA-only input. Each pass runs the fee loop to convergence; a pass that
  // cannot fund the mandatory change output asks for one more input rather than giving up.
  let shortfall = '';
  for (let extra = 0; extra <= spare.length; extra++) {
    const selected = [...assetInputs, ...spare.slice(0, extra)];
    const inputAda = selected.reduce((sum, utxo) => sum + utxo.lovelace, 0n);
    const residual = residualAssets(selected, sent);

    let fee = feeForSize(0, parameters);
    // Distinguishes "this selection cannot pay" — which one more input might fix — from "the fee
    // loop failed to settle", which is a defect and must not be retried into silence.
    let needsMoreAda = false;

    for (let pass = 0; pass < MAX_FEE_PASSES; pass++) {
      const sponsorChoice = sponsor
        ? selectSponsorInputs(
            sponsorAvailable,
            fee + sponsorSupplies,
            sponsor.changeAddress,
            chatterPayFee > 0n ? [feeAsset] : [],
            plan.routeDustToSponsor === true,
            parameters.coinsPerUtxoByte
          )
        : { selected: [] as CardanoUtxo[], residual: [] as CardanoAssetAmount[] };
      const sponsorSelected = sponsorChoice.selected;
      const sponsorTotal = sponsorSelected.reduce((sum, utxo) => sum + utxo.lovelace, 0n);
      // Whatever the sponsor's own inputs carried, on its way back to the sponsor.
      const sponsorResidual = sponsorChoice.residual;

      // What the sender owes, in ADA: the ADA attached to the token output, unless the sponsor is
      // supplying it. ChatterPay's fee is not on this list — it is charged in the token, not in
      // lovelace. The network fee is here only when nobody is sponsoring it.
      const senderOwes = attachedShortfall - sponsorSupplies + (sponsor ? 0n : fee);
      let change = inputAda - senderOwes;
      // Sender lovelace riding home in the sponsor's change because it was too small to stand as an
      // output. Same rule as the ADA path: never when it would carry tokens away with it.
      let routed = 0n;
      if (change < 0n) {
        shortfall = `CARDANO_INSUFFICIENT_FUNDS: ${inputAda} lovelace available, need at least ${senderOwes}`;
        needsMoreAda = true;
        break;
      }

      const changeOutput = encodeOutput(plan.changeAddress, change, residual);
      const minimumChange = minimumAdaForOutput(changeOutput, parameters.coinsPerUtxoByte);
      let keepsChange: boolean;

      if (residual.length > 0) {
        // Mandatory: the tokens have nowhere else to go.
        if (change < minimumChange) {
          shortfall =
            `CARDANO_INSUFFICIENT_FUNDS: change output must hold ${minimumChange} lovelace ` +
            `to carry ${residual.length} residual asset(s), only ${change} available`;
          needsMoreAda = true;
          break;
        }
        keepsChange = true;
      } else if (change > 0n && change < minimumChange) {
        // The same gap the ADA path guards: a remainder too small to stand as its own output is a
        // remainder the network keeps. Asking for more ADA pulls another input in, which is what
        // closes it; running out of inputs is when routing becomes the answer.
        //
        // Held back until the last pass on purpose: another input of the sender's own leaves the
        // money in their wallet, and routing only beats a refusal, not that.
        if (routeDust && extra === spare.length) {
          routed = change;
          change = 0n;
          keepsChange = false;
        } else {
          shortfall =
            `CARDANO_INSUFFICIENT_FUNDS: change of ${change} lovelace is below the ${minimumChange} ` +
            `an output must hold, and would be lost to the network as fee`;
          needsMoreAda = true;
          break;
        }
      } else {
        keepsChange = change > 0n;
      }

      // The sponsor's ADA change is untouched by ChatterPay's fee — that fee is in tokens — but the
      // output it comes back in is what carries them. What does come out of it: the network fee it
      // is covering, the min-ADA it is supplying to the token output under scheme 2, and, added
      // back, whatever of the sender's change had nowhere else to go.
      let sponsorChange = sponsor ? sponsorTotal - fee - sponsorSupplies + routed : 0n;
      const sponsorChangeAssets =
        chatterPayFee > 0n ? mergeAssets(sponsorResidual, [feeAsset]) : sponsorResidual;
      const sponsorChangeOutput = sponsor
        ? encodeOutput(sponsor.changeAddress, sponsorChange, sponsorChangeAssets)
        : new Uint8Array();
      const keepsSponsorChange =
        sponsor !== undefined &&
        sponsorChange > 0n &&
        sponsorChange >= minimumAdaForOutput(sponsorChangeOutput, parameters.coinsPerUtxoByte);
      // Below min-ADA the sponsor's leftover cannot be an output, so it stays in the fee. The
      // sponsor donates it — the same call the ADA path makes, and it never reaches the sender.
      // What the sponsor may not donate is the sender's routed change, which is not its money.
      if (!keepsSponsorChange && routed > 0n) {
        throw new Error(
          `CARDANO_ROUTED_CHANGE_WOULD_BE_BURNED: ${routed} lovelace of the sender's change was ` +
            `routed to the sponsor, whose own change of ${sponsorChange} cannot stand as an output`
        );
      }
      if (!keepsSponsorChange && sponsorChangeAssets.length > 0) {
        throw new Error(
          `CARDANO_SPONSOR_CHANGE_WOULD_BE_BURNED: ${sponsorChange} lovelace cannot stand as an ` +
            `output while carrying ${sponsorChangeAssets.length} token(s) home`
        );
      }
      if (!keepsSponsorChange) sponsorChange = 0n;

      const outputs = [
        paymentOutput,
        ...(keepsChange ? [encodeOutput(plan.changeAddress, change, residual)] : []),
        ...(keepsSponsorChange ? [sponsorChangeOutput] : [])
      ];
      const inputs = [...selected, ...recycled, ...sponsorSelected];
      const bodyFee =
        inputAda + recycledLovelace + sponsorTotal - attached - change - sponsorChange;
      const body = encodeBody(inputs, outputs, bodyFee, ttlSlot);
      const size = signedSizeOf(body);
      if (size > parameters.maxTxSize) {
        throw new Error(`CARDANO_TX_TOO_LARGE: ${size} bytes over ${parameters.maxTxSize}`);
      }

      const required = feeForSize(size, parameters);
      if (required <= fee) {
        return {
          bodyBytes: body,
          changeIndex: keepsChange ? 1 : undefined,
          sponsorChangeIndex: keepsSponsorChange ? outputs.length - 1 : undefined,
          transactionId: transactionIdOf(body),
          fee: bodyFee,
          sentLovelace: attached,
          change,
          changeAssets: residual,
          inputs,
          ttlSlot,
          chatterPayFee,
          routedToSponsor: routed,
          sponsorSuppliedLovelace: sponsorSupplies,
          recycledLovelace,
          sponsorChangeAssets: keepsSponsorChange ? sponsorChangeAssets : []
        };
      }
      fee = required;
    }

    // The fee loop ran out of passes without either settling or asking for more ADA. Each pass can
    // only raise the fee by a byte or two's worth, so more than a handful means the arithmetic is
    // wrong, not that the wallet is short.
    if (!needsMoreAda) throw new Error('CARDANO_FEE_DID_NOT_CONVERGE');
  }

  throw new Error(shortfall || 'CARDANO_INSUFFICIENT_FUNDS');
}
