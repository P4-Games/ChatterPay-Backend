/**
 * Polymarket API Adapter
 *
 * Attaches a bearer token to every outbound request targeting the configured
 * Polymarket base URLs (`POLYMARKET_CLOB_API_URL`, `POLYMARKET_GAMMA_API_URL`,
 * `POLYMARKET_DATA_API_URL`). A single global Axios request handler covers both
 * direct Gamma/Data calls and the CLOB SDK (`@polymarket/clob-client-v2`),
 * since the SDK shares the same hoisted Axios singleton. Only requests whose
 * URL matches a configured Polymarket base URL are touched; unrelated traffic
 * (LiFi, Manteca, Alchemy, The Graph, ...) is never modified. When
 * `POLYMARKET_ADAPTER_AUTH_TOKEN` is unset the adapter is never registered.
 */

import axios, { InternalAxiosRequestConfig } from 'axios';

import * as constants from '../../config/constants';
import { isTestRun } from '../../helpers/envHelper';
import { Logger } from '../../helpers/loggerHelper';

const LOG_PREFIX = 'polymarketAdapterHelper';

let adapterRegistered = false;

/** Polymarket base URLs that require authenticated requests. */
function getProxiedBaseUrls(): string[] {
  return [
    constants.POLYMARKET_CLOB_API_URL,
    constants.POLYMARKET_GAMMA_API_URL,
    constants.POLYMARKET_DATA_API_URL
  ].filter((url): url is string => Boolean(url));
}

/**
 * Resolve the absolute target URL of a request for prefix matching.
 * Exported for unit testing.
 */
export function resolveRequestUrl(config: InternalAxiosRequestConfig): string {
  const url = config.url ?? '';
  if (/^https?:\/\//i.test(url)) return url;
  return `${config.baseURL ?? ''}${url}`;
}

/**
 * True when the request targets one of the configured Polymarket base URLs.
 * Exported for unit testing.
 */
export function targetsProxiedHost(requestUrl: string): boolean {
  return getProxiedBaseUrls().some((base) => requestUrl.startsWith(base));
}

/**
 * Register the global Axios adapter that injects the bearer token
 * into Polymarket-bound requests.
 *
 * Idempotent: safe to call multiple times, registers at most once. No-op when
 * `POLYMARKET_ADAPTER_AUTH_TOKEN` is empty.
 */
export function registerPolymarketApiAdapter(): void {
  if (adapterRegistered) return;
  const adapterToken = constants.POLYMARKET_ADAPTER_AUTH_TOKEN;
  if (!adapterToken) return;

  axios.interceptors.request.use((config) => {
    const requestUrl = resolveRequestUrl(config);
    if (requestUrl && targetsProxiedHost(requestUrl)) {
      config.headers.set('Authorization', `Bearer ${adapterToken}`);
    }
    return config;
  });

  adapterRegistered = true;
  Logger.log('info', `[${LOG_PREFIX}:register]`, 'Polymarket API adapter registered');
}

/**
 * Reset the adapter registration flag.
 * **For use in tests only** – allows re-registering the adapter in isolated
 * test cases without reloading the module.
 * @internal
 */
export function _resetAdapterForTesting(): void {
  if (!isTestRun()) return;
  adapterRegistered = false;
}
