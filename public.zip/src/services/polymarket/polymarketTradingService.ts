/**
 * Polymarket Trading Service
 *
 * Handles order placement, cancellation, and position queries.
 * All operations require an authenticated CLOB client.
 *
 * @see https://docs.polymarket.com/trading/quickstart
 */

import { AssetType, OrderType, Side, type TickSize } from '@polymarket/clob-client-v2';
import axios from 'axios';
import { ethers } from 'ethers';

import {
  POLYMARKET_DATA_API_URL,
  POLYMARKET_GAMMA_API_URL,
  POLYMARKET_POLYGON_RPC_URL,
  POLYMARKET_USER_PNL_API_URL
} from '../../config/constants';
import { Logger } from '../../helpers/loggerHelper';
import { PolymarketOrderModel } from '../../models/polymarketModel';
import type { IUser } from '../../models/userModel';
import { mongoTransactionService } from '../mongo/mongoTransactionService';
import {
  getAuthenticatedClientForUser,
  PolymarketAccountMismatchError
} from './polymarketClientService';
import {
  CTF_ADDRESS,
  FOK_SLIPPAGE_TOLERANCE,
  WITHDRAWABLE_STABLECOINS
} from './polymarketConstants';
import { mapClobStatusToTxStatus } from './polymarketHistoryService';
import { ensureTokenApprovals, setupDepositWalletApprovals } from './polymarketRelayerService';
import type {
  ClobOpenOrder,
  ClobOrderResponse,
  DataPosition,
  DataTrade,
  DataTradeActivity,
  PlaceOrderParams,
  PnlHistoryPoint,
  PnlInterval,
  TradeHistoryQuery,
  UserPnlApiPoint
} from './polymarketTypes';

const LOG_PREFIX = 'polymarketTradingService';

/**
 * Turn a CLOB SDK failure into a message that names the account it was made with.
 *
 * The SDK parses every response as a result set, so a rejected request surfaces as a spread over an
 * undefined body rather than as its status. On its own that reads as a bug in our code; paired with
 * the signer and funder it reads as what it is, credentials the CLOB refused.
 */
function describeClobFailure(error: unknown, user: IUser): string {
  const account = user.polymarket_account;
  const context = account
    ? ` [signer=${account.signer_address ?? 'unrecorded'} funder=${account.polygon_address} walletType=${account.wallet_type ?? 'safe'}]`
    : '';

  if (error instanceof PolymarketAccountMismatchError) return error.message;

  if (error instanceof TypeError && /spread syntax/i.test(error.message)) {
    return `CLOB rejected the request and returned no result set (usually 401 on invalid or mismatched API credentials): ${String(error)}${context}`;
  }

  return `${String(error)}${context}`;
}

// CLOB error detection patterns — extracted to avoid brittle inline string matching
const CLOB_ERROR_PATTERNS = {
  ALLOWANCE: ['not enough balance', 'allowance'],
  MIN_SIZE: ['lower than the minimum']
} as const;

// Grace window before reconciling a just-placed order against the CLOB.
//
// A marketable order (FOK / crossing GTC) leaves the order book the instant it
// is accepted, and its fill settles on the CLOB asynchronously over a few
// seconds. If syncOpenOrders runs inside this window (the frontend polls
// /positions and /orders immediately after a purchase), getOrder transiently
// reports `size_matched=0 / status=CANCELED` for an order that actually filled —
// which would wrongly downgrade it to `cancelled` (rendered as "failed" in the
// app). Deferring the verdict until the fill has settled avoids that race.
const ORDER_SYNC_GRACE_MS = 60_000;

function matchesClobError(detail: string, patterns: readonly string[]): boolean {
  const lower = detail.toLowerCase();
  return patterns.some((p) => lower.includes(p));
}

// The CLOB SDK indexes ROUNDING_CONFIG by tick size string; any value outside
// this set (e.g. "0" from a bad/rate-limited tick-size response cached by the
// SDK) makes order building crash with
// "undefined is not an object (evaluating 'roundConfig.price')".
const VALID_TICK_SIZES: readonly TickSize[] = ['0.1', '0.01', '0.001', '0.0001'];

function toValidTickSize(value: number): TickSize | undefined {
  return VALID_TICK_SIZES.find((t) => Number(t) === value);
}

/**
 * Snap a price to the market's tick grid and clamp it to the valid range.
 *
 * Polymarket only accepts prices that are multiples of the market's tick size,
 * within [tick, 1 - tick]. A 0.01-tick market (most binary/sports) caps at 0.99,
 * so a slippage price of 0.999 is rejected with
 * "invalid price (0.999), min: 0.01 - max: 0.99". Ticks are always powers of ten
 * (0.1 / 0.01 / 0.001 / 0.0001), so toFixed(decimals) yields a valid multiple.
 */
function clampPriceToTick(price: number, tickSize: number): number {
  const decimals = Math.max(0, Math.round(-Math.log10(tickSize)));
  const rounded = Number(price.toFixed(decimals));
  return Math.min(Math.max(rounded, tickSize), 1 - tickSize);
}

async function ensureApprovals(user: IUser, privateKey: string, logKey: string): Promise<void> {
  const walletType = user.polymarket_account?.wallet_type ?? 'safe';
  if (walletType === 'deposit') {
    const depositWallet = user.polymarket_account!.polygon_address;
    await setupDepositWalletApprovals(privateKey, depositWallet, logKey);
  } else {
    await ensureTokenApprovals(privateKey, logKey);
  }
}

// ============================================================================
// Helpers
// ============================================================================

/**
 * Resolve 'max' size for SELL orders by querying the CLOB conditional token balance.
 * Returns the human-readable share count (e.g. 1.11) for the given token.
 */
export async function resolveMaxSize(
  user: IUser,
  privateKey: string,
  tokenId: string,
  logKey: string
): Promise<number> {
  const fnLog = `[${LOG_PREFIX}:resolveMaxSize]`;
  const client = await getAuthenticatedClientForUser(user, privateKey);

  const conditionalParams = { asset_type: AssetType.CONDITIONAL, token_id: tokenId };
  await client.updateBalanceAllowance(conditionalParams);
  const status = await client.getBalanceAllowance(conditionalParams);
  const rawBalance = Number(status?.balance ?? 0);
  const shares = rawBalance / 1_000_000;

  Logger.log('info', fnLog, `${logKey} Resolved max size: ${shares} shares (raw=${rawBalance})`);

  if (shares <= 0) {
    throw new Error('No shares found for this token. Cannot sell with size=max.');
  }
  return shares;
}

// ============================================================================
// Order Management
// ============================================================================

/**
 * Place an order on Polymarket.
 * Automatically fetches tick size and neg_risk from the market.
 * The CLOB client handles on-chain approvals via the operator/API key system.
 *
 * @param user - User with polymarket_account
 * @param privateKey - User's EOA private key
 * @param params - Order parameters
 * @returns Order response with ID and status
 */
export async function placeOrder(
  user: IUser,
  privateKey: string,
  params: PlaceOrderParams,
  logKey: string
): Promise<ClobOrderResponse> {
  const fnLog = `[${LOG_PREFIX}:placeOrder]`;

  try {
    Logger.log(
      'info',
      fnLog,
      `${logKey} Placing ${params.side} order: ${params.size}@${params.price}`
    );

    const client = await getAuthenticatedClientForUser(user, privateKey);

    // Collateral balance (human USD) as reported by the CLOB — captured during the
    // pre-flight check below and passed to the SDK so BUY amounts are auto-reduced
    // to fit balance + fee estimate.
    let collateralBalanceUsd: number | undefined;

    // Ensure the CLOB's cached balance/allowance is fresh before placing the order.
    //
    // For CONDITIONAL (SELL), the CLOB API requires the specific token_id
    // because ERC-1155 balances are per-token. Without it the API returns:
    //   "assetId invalid value -1, as this is a erc1155 operation"
    //
    // IMPORTANT: The CLOB's getBalanceAllowance for AssetType.CONDITIONAL
    // returns allowance=0 even when on-chain setApprovalForAll is set.
    // ERC-1155 uses boolean operator approvals (isApprovedForAll), not
    // granular ERC-20-style allowances, so the CLOB's allowance field is
    // unreliable for CONDITIONAL tokens. We only use it for COLLATERAL.
    try {
      const isSell = params.side === 'SELL';

      if (isSell) {
        // SELL: Validate conditional token balance. Don't gate on allowance
        // (always reads 0 for ERC-1155). On-chain approvals are set once
        // during account creation via setupGaslessTrading/ensureTokenApprovals.
        const conditionalParams = { asset_type: AssetType.CONDITIONAL, token_id: params.tokenId };

        Logger.log('info', fnLog, `${logKey} Refreshing CLOB cache for CONDITIONAL + COLLATERAL`);
        const [conditionalResult, collateralResult] = await Promise.allSettled([
          client.updateBalanceAllowance(conditionalParams),
          client.updateBalanceAllowance({ asset_type: AssetType.COLLATERAL })
        ]);
        if (conditionalResult.status === 'rejected') {
          throw new Error(
            `Failed to refresh CONDITIONAL balance: ${String(conditionalResult.reason)}`
          );
        }
        if (collateralResult.status === 'rejected') {
          Logger.log(
            'warn',
            fnLog,
            `${logKey} COLLATERAL refresh failed (non-critical): ${String(collateralResult.reason)}`
          );
        }

        const allowanceStatus = await client.getBalanceAllowance(conditionalParams);
        const currentBalance = Number(allowanceStatus?.balance ?? 0);

        Logger.log(
          'info',
          fnLog,
          `${logKey} CONDITIONAL balance=${currentBalance} (${currentBalance / 1_000_000} shares)`
        );

        // Validate balance before submitting
        const balanceHuman = currentBalance / 1_000_000;
        if (currentBalance === 0) {
          throw new Error(
            `No shares found for this token in your Polymarket account. ` +
              `Check your positions before selling.`
          );
        }
        if (balanceHuman < params.size) {
          throw new Error(
            `Insufficient shares: you have ${balanceHuman} but trying to sell ${params.size}. ` +
              `Reduce size to ${balanceHuman} or less.`
          );
        }
      } else {
        // BUY: Check COLLATERAL (pUSD) balance/allowance.
        // ERC-20 allowances ARE reported correctly by the CLOB.
        const collateralParams = { asset_type: AssetType.COLLATERAL };

        Logger.log('info', fnLog, `${logKey} Refreshing CLOB cache for COLLATERAL`);
        await client.updateBalanceAllowance(collateralParams);

        const allowanceStatus = await client.getBalanceAllowance(collateralParams);
        const currentBalance = Number(allowanceStatus?.balance ?? 0);
        collateralBalanceUsd = currentBalance / 1_000_000;
        const allowances = allowanceStatus?.allowances ?? {};
        const hasAnyAllowance = Object.values(allowances).some((v) => Number(v) > 0);

        Logger.log(
          'info',
          fnLog,
          `${logKey} COLLATERAL balance=${currentBalance}, allowances=${JSON.stringify(allowances)}`
        );

        if (!hasAnyAllowance) {
          Logger.log(
            'info',
            fnLog,
            `${logKey} No COLLATERAL allowance — setting up approvals via Relayer`
          );
          await ensureApprovals(user, privateKey, logKey);
          await new Promise((resolve) => setTimeout(resolve, 2000));
          await client.updateBalanceAllowance(collateralParams);
          Logger.log('info', fnLog, `${logKey} Approvals set and CLOB cache refreshed`);
        } else {
          Logger.log('info', fnLog, `${logKey} COLLATERAL allowance already cached on CLOB`);
        }
      }
    } catch (allowanceError) {
      if (
        String(allowanceError).includes('No shares found') ||
        String(allowanceError).includes('Insufficient shares')
      ) {
        throw allowanceError;
      }
      Logger.log(
        'warn',
        fnLog,
        `${logKey} Allowance check/update failed (non-fatal): ${String(allowanceError)}`
      );
    }

    const side = params.side === 'BUY' ? Side.BUY : Side.SELL;

    // For BUYs, tell the SDK how much collateral is actually available so it can
    // deduct the CLOB fee estimate from the order notional (fee = shares × rate ×
    // (p(1-p))^exp, up to ~5% of the amount). Without this the CLOB rejects with
    // "not enough balance / allowance ... fee estimate" whenever balance ≈ amount.
    // Use the smaller of the CLOB-reported balance and the caller's available
    // figure (on-chain minus funds committed to concurrent in-flight orders).
    const balanceCandidates = [collateralBalanceUsd, params.availableUsdc].filter(
      (v): v is number => typeof v === 'number'
    );
    const userUSDCBalance =
      params.side === 'BUY' && balanceCandidates.length > 0
        ? Math.min(...balanceCandidates)
        : undefined;

    // Fetch the market's tick size to compute valid price bounds. Polymarket
    // accepts prices in [tick, 1 - tick] as multiples of the tick; hardcoding
    // 0.999/0.001 only works for 0.001-tick markets and gets rejected on the
    // common 0.01-tick (binary/sports) markets.
    let tickSizeStr: TickSize = '0.01';
    try {
      const fetched = Number(await client.getTickSize(params.tokenId));
      const valid = toValidTickSize(fetched);
      if (valid) {
        tickSizeStr = valid;
      } else {
        Logger.log(
          'warn',
          fnLog,
          `${logKey} Fetched tick size ${fetched} is not a valid tick, defaulting to ${tickSizeStr}`
        );
      }
    } catch (tickError) {
      Logger.log(
        'warn',
        fnLog,
        `${logKey} Failed to fetch tick size, defaulting to ${tickSizeStr}: ${String(tickError)}`
      );
    }
    const tickSize = Number(tickSizeStr);
    // Always pass the validated tick size to the SDK. Without it, the SDK
    // resolves the tick from its own cache, which can hold an invalid value
    // when the tick-size request failed (rate limit) — crashing order building.
    const orderOptions = { tickSize: tickSizeStr };

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const submitOrder = async (): Promise<any> => {
      if (params.orderType === 'FOK') {
        // FOK orders use createAndPostMarketOrder (fill-or-kill).
        // SDK UserMarketOrder.amount semantics:
        //   BUY  → dollar amount to spend (price × size)
        //   SELL → number of shares to sell (size)
        //
        // `price` is the worst acceptable price (slippage protection).
        // `amount` stays based on the original price so we don't overspend.
        const amount = params.side === 'BUY' ? params.price * params.size : params.size;

        // CLOB V2 enforces $1 minimum for marketable BUY orders.
        // Fail fast with a helpful message rather than letting the CLOB reject.
        if (params.side === 'BUY' && amount < 1.0) {
          const minShares = Math.ceil((1.0 / params.price) * 10000) / 10000;
          throw new Error(
            `FOK BUY order amount $${amount.toFixed(4)} is below Polymarket's $1.00 minimum. ` +
              `At price $${params.price}, use at least ${minShares} shares.`
          );
        }
        const rawSlippagePrice =
          params.side === 'BUY'
            ? params.price * (1 + FOK_SLIPPAGE_TOLERANCE)
            : params.price * (1 - FOK_SLIPPAGE_TOLERANCE);
        const slippagePrice = clampPriceToTick(rawSlippagePrice, tickSize);

        Logger.log(
          'info',
          fnLog,
          `${logKey} FOK order: amount=${amount.toFixed(2)}, ` +
            `price=${params.price} → slippagePrice=${slippagePrice.toFixed(4)}`
        );

        return client.createAndPostMarketOrder(
          {
            tokenID: params.tokenId,
            price: slippagePrice,
            amount,
            side,
            userUSDCBalance
          },
          orderOptions
        );
      }
      // GTC (default) and GTD orders use createAndPostOrder
      const orderType = params.orderType === 'GTD' ? OrderType.GTD : OrderType.GTC;
      return client.createAndPostOrder(
        {
          tokenID: params.tokenId,
          price: params.price,
          size: params.size,
          side,
          userUSDCBalance
        },
        orderOptions,
        orderType
      );
    };

    // The SDK returns OrderResponse which may carry orderID+status on success, or error+message on
    // failure, but its type definition lacks an index signature and is not assignable to
    // Record<string, unknown>. Cast through `any` so response handling can read all fields.
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let response: any = await submitOrder();

    // The CLOB SDK may swallow HTTP errors and return the error body
    // instead of throwing (e.g. {"error": "not enough balance / allowance"}).
    // Detect this and throw so callers get a proper failure.
    if (!response.orderID) {
      const errorDetail = String(response.error || response.message || 'no orderID in response');

      // For SELL orders that fail with allowance errors, retry once after
      // setting fresh approvals. The CLOB cache for ERC-1155 (CONDITIONAL)
      // is unreliable — the on-chain approval may exist but not be cached.
      const isAllowanceError = matchesClobError(errorDetail, CLOB_ERROR_PATTERNS.ALLOWANCE);
      const isMinSizeError = matchesClobError(errorDetail, CLOB_ERROR_PATTERNS.MIN_SIZE);

      if (params.side === 'SELL' && isAllowanceError) {
        Logger.log(
          'warn',
          fnLog,
          `${logKey} SELL rejected (${errorDetail}). Setting fresh approvals and retrying...`
        );
        await ensureApprovals(user, privateKey, logKey);
        await new Promise((resolve) => setTimeout(resolve, 5000));

        // Refresh both asset type caches after approvals
        await Promise.all([
          client.updateBalanceAllowance({
            asset_type: AssetType.CONDITIONAL,
            token_id: params.tokenId
          }),
          client.updateBalanceAllowance({ asset_type: AssetType.COLLATERAL })
        ]);

        response = await submitOrder();

        // After retry, check again — might reveal a different error (e.g. min size)
        if (!response.orderID) {
          const retryDetail = String(response.error || response.message || '');

          // If GTC still fails, fall back to FOK market order (works for both
          // balance/allowance and minimum-size errors)
          if (params.orderType !== 'FOK') {
            Logger.log(
              'warn',
              fnLog,
              `${logKey} GTC SELL failed after retry (${retryDetail}). Falling back to FOK market order.`
            );
            response = await client.createAndPostMarketOrder(
              {
                tokenID: params.tokenId,
                price: clampPriceToTick(params.price, tickSize),
                amount: params.size,
                side
              },
              orderOptions
            );
            if (!response.orderID) {
              const fokError = response.error || response.message || 'no orderID in response';
              throw new Error(`CLOB rejected FOK fallback: ${fokError}`);
            }
          } else {
            throw new Error(
              `CLOB rejected order after retry: ${retryDetail || 'no orderID in response'}`
            );
          }
        }
      } else if (params.side === 'BUY' && isAllowanceError) {
        // BUY rejected on balance/allowance — the CLOB's cached balance can lag
        // a just-completed bridge. Refresh the collateral cache and retry once
        // (the SDK re-caps the amount to balance + fee via userUSDCBalance).
        Logger.log(
          'warn',
          fnLog,
          `${logKey} BUY rejected (${errorDetail}). Refreshing CLOB balance cache and retrying...`
        );
        await client.updateBalanceAllowance({ asset_type: AssetType.COLLATERAL });
        await new Promise((resolve) => setTimeout(resolve, 3000));

        response = await submitOrder();
        if (!response.orderID) {
          const retryDetail = String(
            response.error || response.message || 'no orderID in response'
          );
          throw new Error(`CLOB rejected order after retry: ${retryDetail}`);
        }
      } else if (params.side === 'SELL' && isMinSizeError && params.orderType !== 'FOK') {
        // GTC SELL rejected for being below minimum order size.
        // Fall back to FOK (market order) which typically has lower minimums.
        Logger.log(
          'warn',
          fnLog,
          `${logKey} GTC SELL below minimum (${errorDetail}). Falling back to FOK market order.`
        );
        response = await client.createAndPostMarketOrder(
          {
            tokenID: params.tokenId,
            price: clampPriceToTick(params.price, tickSize),
            amount: params.size,
            side
          },
          orderOptions
        );
        if (!response.orderID) {
          const fokError = response.error || response.message || 'no orderID in response';
          throw new Error(`CLOB rejected FOK fallback: ${fokError}`);
        }
      } else {
        throw new Error(`CLOB rejected order: ${errorDetail}`);
      }
    }

    Logger.log('info', fnLog, `${logKey} Order placed: ${response.orderID}`);
    return response as unknown as ClobOrderResponse;
  } catch (error) {
    Logger.log('error', fnLog, `${logKey} Failed: ${String(error)}`);
    throw new Error(`Failed to place order: ${String(error)}`);
  }
}

/**
 * Cancel a specific open order.
 */
export async function cancelOrder(
  user: IUser,
  privateKey: string,
  orderId: string,
  logKey: string
): Promise<void> {
  const fnLog = `[${LOG_PREFIX}:cancelOrder]`;

  try {
    Logger.log('info', fnLog, `${logKey} Cancelling order: ${orderId}`);
    const client = await getAuthenticatedClientForUser(user, privateKey);
    await client.cancelOrder({ orderID: orderId });
    Logger.log('info', fnLog, `${logKey} Order cancelled: ${orderId}`);
  } catch (error) {
    Logger.log('error', fnLog, `${logKey} Failed: ${String(error)}`);
    throw new Error(`Failed to cancel order: ${String(error)}`);
  }
}

/**
 * Cancel all open orders for the user.
 */
export async function cancelAllOrders(
  user: IUser,
  privateKey: string,
  logKey: string
): Promise<void> {
  const fnLog = `[${LOG_PREFIX}:cancelAllOrders]`;

  try {
    Logger.log('info', fnLog, `${logKey} Cancelling all orders`);
    const client = await getAuthenticatedClientForUser(user, privateKey);
    await client.cancelAll();
    Logger.log('info', fnLog, `${logKey} All orders cancelled`);
  } catch (error) {
    Logger.log('error', fnLog, `${logKey} Failed: ${String(error)}`);
    throw new Error(`Failed to cancel all orders: ${String(error)}`);
  }
}

/**
 * Get open orders for the user.
 */
export async function getOpenOrders(
  user: IUser,
  privateKey: string,
  logKey: string
): Promise<ClobOpenOrder[]> {
  const fnLog = `[${LOG_PREFIX}:getOpenOrders]`;

  try {
    const client = await getAuthenticatedClientForUser(user, privateKey);
    const orders = await client.getOpenOrders();

    return orders as unknown as ClobOpenOrder[];
  } catch (error) {
    const detail = describeClobFailure(error, user);
    Logger.log('error', fnLog, `${logKey} Failed: ${detail}`);
    throw new Error(`Failed to fetch open orders: ${detail}`);
  }
}

// ============================================================================
// Data API — Positions & History
// ============================================================================

import NodeCache from 'node-cache';

const tokenMarketCache = new NodeCache({ stdTTL: 3600, maxKeys: 2000 });

async function enrichWithMarketData(
  tokenId: string,
  logKey: string
): Promise<{ market_title: string; market_slug: string }> {
  const cached = tokenMarketCache.get<{ market_title: string; market_slug: string }>(tokenId);
  if (cached) return cached;

  try {
    const response = await axios.get(`${POLYMARKET_GAMMA_API_URL}/markets`, {
      params: { clobTokenIds: tokenId },
      timeout: 5000
    });

    if (response.data && response.data.length > 0) {
      const market = response.data[0];
      const result = {
        market_title: market.question || market.title || 'Unknown Market',
        market_slug: market.slug || ''
      };
      tokenMarketCache.set(tokenId, result);
      return result;
    }
  } catch (err) {
    Logger.log(
      'warn',
      `[${LOG_PREFIX}:enrichment]`,
      `Failed to enrich token ${tokenId} from Gamma: ${String(err)}`
    );
  }

  // Best-effort local DB fallback
  try {
    const localOrder = await PolymarketOrderModel.findOne({ token_id: tokenId })
      .select('market_slug')
      .lean();
    if (localOrder && localOrder.market_slug) {
      const result = {
        market_title: 'Unknown Market (Local)',
        market_slug: localOrder.market_slug
      };
      tokenMarketCache.set(tokenId, result);
      return result;
    }
  } catch (dbErr) {
    Logger.log(
      'warn',
      `[${LOG_PREFIX}:enrichment]`,
      `Failed local fallback for token ${tokenId}: ${String(dbErr)}`
    );
  }

  const defaultResult = { market_title: 'Unknown Market', market_slug: '' };
  tokenMarketCache.set(tokenId, defaultResult);
  return defaultResult;
}

async function enrichItems<T extends { asset?: string; token_id?: string }>(
  items: T[],
  logKey: string
): Promise<(T & { market_title?: string; market_slug?: string })[]> {
  // Collect unique uncached tokenIds to batch-fetch from Gamma
  const uncachedIds = new Set<string>();
  for (const item of items) {
    const tokenId = item.asset || item.token_id;
    if (tokenId && tokenId !== 'USDC' && !tokenMarketCache.get(tokenId)) {
      uncachedIds.add(tokenId);
    }
  }

  // Batch-fetch uncached tokens from Gamma (up to 20 per request)
  if (uncachedIds.size > 0) {
    const batches: string[][] = [];
    const ids = [...uncachedIds];
    for (let i = 0; i < ids.length; i += 20) {
      batches.push(ids.slice(i, i + 20));
    }

    await Promise.all(
      batches.map(async (batch) => {
        try {
          const response = await axios.get(`${POLYMARKET_GAMMA_API_URL}/markets`, {
            params: { clobTokenIds: batch.join(',') },
            timeout: 10000
          });

          if (response.data && Array.isArray(response.data)) {
            for (const market of response.data) {
              // Gamma returns markets with tokens[].token_id — match against our batch
              const marketTokenIds: string[] = (market.tokens || [])
                .map((t: { token_id?: string }) => t.token_id)
                .filter(Boolean);

              const result = {
                market_title: market.question || market.title || 'Unknown Market',
                market_slug: market.slug || ''
              };

              for (const tid of marketTokenIds) {
                if (uncachedIds.has(tid)) {
                  tokenMarketCache.set(tid, result);
                }
              }

              // Also cache by condition_id if it matches a batch ID directly
              if (market.condition_id && uncachedIds.has(market.condition_id)) {
                tokenMarketCache.set(market.condition_id, result);
              }
            }
          }
        } catch (err) {
          Logger.log(
            'warn',
            `[${LOG_PREFIX}:enrichment]`,
            `${logKey} Batch Gamma fetch failed for ${batch.length} tokens: ${String(err)}`
          );
        }
      })
    );
  }

  // Now enrich each item from cache (with fallback for any still-uncached)
  return Promise.all(
    items.map(async (item) => {
      const tokenId = item.asset || item.token_id;
      if (tokenId && tokenId !== 'USDC') {
        const metadata = await enrichWithMarketData(tokenId, logKey);
        return { ...item, ...metadata };
      }
      return item;
    })
  );
}

/**
 * A position in a market that has resolved AGAINST the user: the Data API marks
 * it `redeemable` (the market settled on-chain) yet it priced out near zero.
 * These can no longer be sold — there is no order book on a resolved market — so
 * they belong in the closed list, not among active/sellable positions.
 *
 * Winning resolved positions also carry `redeemable: true` but settle near 1
 * (curPrice ≈ 1); they stay active because they're still claimable. The 0.5
 * cutoff cleanly separates the two since a resolved binary market pays 0 or 1.
 */
function isResolvedLostPosition(p: DataPosition): boolean {
  return p.redeemable === true && (p.curPrice ?? 0) < 0.5;
}

/**
 * Fold a closed position's realized P&L into its `cashPnl`.
 *
 * The Data API reports `cashPnl` as only the UNREALIZED P&L on tokens still held,
 * and `realizedPnl` as the P&L from the portion already sold or redeemed. For a
 * closed position either or both may apply:
 *  - redeemed winner: tokens gone (cashPnl 0), profit sits in realizedPnl;
 *  - bought-and-held loser: still holds worthless tokens, full loss in cashPnl;
 *  - partially sold before resolution: loss/gain split across both fields.
 *
 * Summing them (they cover disjoint token lots, so no double-counting) yields the
 * true total P&L. `percentPnl` is recomputed against the full cost basis.
 */
function withTotalPnl(p: DataPosition): DataPosition {
  const totalPnl = (p.cashPnl ?? 0) + (p.realizedPnl ?? 0);
  const cost = p.totalBought || p.initialValue || (p.size ?? 0) * (p.avgPrice ?? 0);
  return {
    ...p,
    cashPnl: totalPnl,
    percentPnl: cost > 0 ? totalPnl / cost : (p.percentPnl ?? 0)
  };
}

/** Fetch raw (unfiltered) positions from the Data API, enriched with market metadata. */
async function fetchRawPositions(
  userAddress: string,
  logKey: string,
  market?: string
): Promise<DataPosition[]> {
  const params: Record<string, unknown> = { user: userAddress };
  if (market) params.market = market;

  const response = await axios.get<DataPosition[]>(`${POLYMARKET_DATA_API_URL}/positions`, {
    params,
    timeout: 10000
  });

  const enriched = await enrichItems(response.data, logKey);
  return enriched as DataPosition[];
}

/**
 * Get current ACTIVE positions for a user address.
 *
 * Excludes positions in markets that resolved against the user (priced to ~0):
 * they can no longer be sold and are surfaced via getClosedPositions instead.
 * Winning resolved positions are kept so the claim flow can still redeem them.
 */
export async function getPositions(
  userAddress: string,
  logKey: string,
  market?: string
): Promise<DataPosition[]> {
  const fnLog = `[${LOG_PREFIX}:getPositions]`;

  try {
    const positions = await fetchRawPositions(userAddress, logKey, market);
    return positions.filter((p) => !isResolvedLostPosition(p));
  } catch (error) {
    Logger.log('error', fnLog, `${logKey} Failed: ${String(error)}`);
    throw new Error(`Failed to fetch positions: ${String(error)}`);
  }
}

/**
 * Get closed positions for a user address.
 *
 * Combines two sources:
 *  1. Polymarket's /closed-positions feed (positions the user fully exited).
 *  2. Positions still held in markets that resolved against the user — these
 *     never reach /closed-positions because the worthless tokens were never
 *     sold/redeemed, yet they're effectively closed (unsellable).
 */
export async function getClosedPositions(
  userAddress: string,
  logKey: string,
  market?: string
): Promise<DataPosition[]> {
  const fnLog = `[${LOG_PREFIX}:getClosedPositions]`;

  try {
    const params: Record<string, unknown> = { user: userAddress };
    if (market) params.market = market;

    const [closedResponse, activePositions] = await Promise.all([
      axios.get<DataPosition[]>(`${POLYMARKET_DATA_API_URL}/closed-positions`, {
        params,
        timeout: 10000
      }),
      fetchRawPositions(userAddress, logKey, market).catch(() => [] as DataPosition[])
    ]);

    const enrichedClosed = (await enrichItems(closedResponse.data, logKey)) as DataPosition[];
    const resolvedLost = activePositions.filter(isResolvedLostPosition);

    // Fold realized P&L into cashPnl for every closed position, so redeemed winners
    // show their gain and positions partially sold before resolution report the full
    // loss/gain rather than only the unrealized slice on the tokens still held.
    return [...enrichedClosed, ...resolvedLost].map(withTotalPnl);
  } catch (error) {
    Logger.log('error', fnLog, `${logKey} Failed: ${String(error)}`);
    throw new Error(`Failed to fetch closed positions: ${String(error)}`);
  }
}

/**
 * Get trade activity history for a user address.
 */
export async function getTradeHistory(
  userAddress: string,
  logKey: string,
  market?: string
): Promise<DataTradeActivity[]> {
  const fnLog = `[${LOG_PREFIX}:getTradeHistory]`;

  try {
    const params: Record<string, unknown> = { user: userAddress };
    if (market) params.market = market;

    const response = await axios.get<DataTradeActivity[]>(`${POLYMARKET_DATA_API_URL}/activity`, {
      params,
      timeout: 10000
    });

    const enriched = await enrichItems(response.data, logKey);
    return enriched as DataTradeActivity[];
  } catch (error) {
    Logger.log('error', fnLog, `${logKey} Failed: ${String(error)}`);
    throw new Error(`Failed to fetch trade history: ${String(error)}`);
  }
}

/**
 * Get portfolio value for a user address.
 */
export async function getPortfolioValue(
  userAddress: string,
  logKey: string
): Promise<Record<string, unknown>> {
  const fnLog = `[${LOG_PREFIX}:getPortfolioValue]`;

  try {
    const response = await axios.get<Record<string, unknown>>(`${POLYMARKET_DATA_API_URL}/value`, {
      params: { user: userAddress },
      timeout: 10000
    });

    return response.data;
  } catch (error) {
    Logger.log('error', fnLog, `${logKey} Failed: ${String(error)}`);
    throw new Error(`Failed to fetch portfolio value: ${String(error)}`);
  }
}

/**
 * Get trades history for a user address with optional filters.
 * Uses the /trades endpoint which supports market, side, limit, offset.
 */
export async function getTradesHistory(
  userAddress: string,
  query: TradeHistoryQuery,
  logKey: string
): Promise<DataTrade[]> {
  const fnLog = `[${LOG_PREFIX}:getTradesHistory]`;

  try {
    const params: Record<string, unknown> = { user: userAddress };
    if (query.market) params.market = query.market;
    if (query.limit) params.limit = query.limit;
    if (query.offset) params.offset = query.offset;
    if (query.side) params.side = query.side;

    const response = await axios.get<DataTrade[]>(`${POLYMARKET_DATA_API_URL}/trades`, {
      params,
      timeout: 15000
    });

    return response.data;
  } catch (error) {
    Logger.log('error', fnLog, `${logKey} Failed: ${String(error)}`);
    throw new Error(`Failed to fetch trades history: ${String(error)}`);
  }
}

/**
 * LTTB (Largest Triangle Three Buckets) downsampling.
 *
 * Reduces a time-series to `target` points while preserving visually significant
 * peaks and valleys — much better than uniform stride-based sampling for charts.
 *
 * @see https://skemman.is/bitstream/1946/15343/3/SS_MSthesis.pdf
 */
function lttbDownsample(points: PnlHistoryPoint[], target: number): PnlHistoryPoint[] {
  const len = points.length;
  if (target >= len || target < 3) return points.slice();

  const sampled: PnlHistoryPoint[] = [points[0]]; // Always keep first point
  const bucketSize = (len - 2) / (target - 2);

  let prevIndex = 0;

  for (let bucket = 1; bucket < target - 1; bucket++) {
    // Current bucket boundaries
    const bucketStart = Math.floor((bucket - 1) * bucketSize) + 1;
    const bucketEnd = Math.min(Math.floor(bucket * bucketSize) + 1, len - 1);

    // Next bucket boundaries (for computing the average point)
    const nextBucketStart = Math.floor(bucket * bucketSize) + 1;
    const nextBucketEnd = Math.min(Math.floor((bucket + 1) * bucketSize) + 1, len - 1);

    // Average of the NEXT bucket (used as the third vertex of the triangle)
    let avgX = 0;
    let avgY = 0;
    const nextBucketLen = nextBucketEnd - nextBucketStart + 1;
    for (let j = nextBucketStart; j <= nextBucketEnd; j++) {
      avgX += new Date(points[j].timestamp).getTime();
      avgY += points[j].cumulativePnl;
    }
    avgX /= nextBucketLen;
    avgY /= nextBucketLen;

    // Previous selected point (first vertex)
    const prevX = new Date(points[prevIndex].timestamp).getTime();
    const prevY = points[prevIndex].cumulativePnl;

    // Find the point in current bucket that maximizes triangle area
    let maxArea = -1;
    let bestIndex = bucketStart;

    for (let j = bucketStart; j <= bucketEnd; j++) {
      const currX = new Date(points[j].timestamp).getTime();
      const currY = points[j].cumulativePnl;
      // Triangle area formula (doubled, sign doesn't matter — we want max absolute)
      const area = Math.abs((prevX - avgX) * (currY - prevY) - (prevX - currX) * (avgY - prevY));
      if (area > maxArea) {
        maxArea = area;
        bestIndex = j;
      }
    }

    sampled.push(points[bestIndex]);
    prevIndex = bestIndex;
  }

  sampled.push(points[len - 1]); // Always keep last point
  return sampled;
}

/**
 * Point density (fidelity) requested from the user-pnl API per interval.
 * Known fidelity values: '1d', '18h', '12h', '3h', '1h'.
 */
const PNL_INTERVAL_FIDELITY: Record<PnlInterval, string> = {
  '1d': '1h',
  '1w': '3h',
  '1m': '12h',
  all: '1d'
};

/**
 * Fallback: compute cumulative REALIZED PNL from all user trades.
 *
 * Fetches all trades via /trades, sorts by timestamp ascending, and computes
 * a running total of cost (BUYs) vs proceeds (SELLs). Note this excludes
 * unrealized P&L on open positions (historical position prices are not
 * available from the /trades endpoint).
 */
async function getPnlHistoryFromTrades(userAddress: string): Promise<PnlHistoryPoint[]> {
  // Fetch all trades (max 10000)
  const response = await axios.get<DataTrade[]>(`${POLYMARKET_DATA_API_URL}/trades`, {
    params: { user: userAddress, limit: 10000 },
    timeout: 30000
  });

  const trades = response.data;
  if (!trades.length) return [];

  // Sort by timestamp ascending (oldest first). Timestamps are epoch SECONDS.
  trades.sort((a, b) => a.timestamp - b.timestamp);

  // Compute cumulative PNL
  let cumulativeCost = 0;
  let cumulativeProceeds = 0;

  return trades.map((trade) => {
    const amount = parseFloat(trade.price) * parseFloat(trade.size);
    if (trade.side === 'BUY') {
      cumulativeCost += amount;
    } else {
      cumulativeProceeds += amount;
    }

    return {
      timestamp: new Date(trade.timestamp * 1000).toISOString(),
      cumulativePnl: cumulativeProceeds - cumulativeCost,
      totalInvested: cumulativeCost,
      totalProceeds: cumulativeProceeds
    };
  });
}

/**
 * Get the user's PNL history time series, suitable for charting.
 *
 * Primary source is Polymarket's official user-pnl API (the same one powering
 * the profit chart on polymarket.com), whose points are mark-to-market —
 * realized + unrealized P&L — and already aggregated server-side, so no
 * per-trade computation is needed. Falls back to a trade-based cumulative
 * realized-PNL computation if that API is unavailable.
 *
 * If `limit` is provided, the resulting points are downsampled to that count.
 */
export async function getPnlHistory(
  userAddress: string,
  logKey: string,
  limit?: number,
  interval: PnlInterval = 'all'
): Promise<PnlHistoryPoint[]> {
  const fnLog = `[${LOG_PREFIX}:getPnlHistory]`;

  let points: PnlHistoryPoint[];
  try {
    const response = await axios.get<UserPnlApiPoint[]>(`${POLYMARKET_USER_PNL_API_URL}/user-pnl`, {
      params: {
        user_address: userAddress,
        interval,
        fidelity: PNL_INTERVAL_FIDELITY[interval]
      },
      timeout: 15000
    });

    points = response.data.map((point) => ({
      timestamp: new Date(point.t * 1000).toISOString(),
      cumulativePnl: point.p
    }));
  } catch (error) {
    Logger.log(
      'warn',
      fnLog,
      `${logKey} user-pnl API failed, falling back to trades: ${String(error)}`
    );
    try {
      points = await getPnlHistoryFromTrades(userAddress);
    } catch (fallbackError) {
      Logger.log('error', fnLog, `${logKey} Failed: ${String(fallbackError)}`);
      throw new Error(`Failed to compute PNL history: ${String(fallbackError)}`);
    }
  }

  // Downsample using LTTB (Largest Triangle Three Buckets) algorithm.
  // Unlike uniform sampling, LTTB preserves visually significant peaks and valleys.
  if (limit && limit > 0 && points.length > limit) {
    return lttbDownsample(points, limit);
  }

  return points;
}

/**
 * Get a summary of the user's Polymarket balances: idle stablecoin + active positions.
 *
 * - idle_usdc: withdrawable stablecoin sitting idle in the Polygon wallet, summed
 *   across every collateral a redemption can pay out (pUSD + legacy USDC.e), PLUS
 *   the value of resolved-and-won positions not yet redeemed. This is the total the
 *   user can sweep to Scroll, so the front can surface it and trigger a withdrawal.
 *   Also checks safeAddress (deposit wallet users may have stranded funds there).
 * - positions_value: total current value of active positions (in USD), excluding
 *   resolved-won positions — those are either counted in idle_usdc (claimable) or
 *   already redeemed (their payout is in the wallet), never in both buckets.
 *
 * This is best-effort: failures return zeroes so the balance endpoint stays resilient.
 *
 * @param polygonAddress - User's Polygon address (deposit wallet or Safe)
 * @param logKey - Logging identifier
 * @param safeAddress - Optional Safe address to also check (for deposit wallet users)
 */
export async function getPolymarketBalanceSummary(
  polygonAddress: string,
  logKey: string,
  safeAddress?: string
): Promise<{ idle_usdc: number; positions_value: number }> {
  const fnLog = `[${LOG_PREFIX}:getPolymarketBalanceSummary]`;

  try {
    // Query idle balance for every withdrawable stablecoin + active positions in parallel.
    // Check both polygonAddress and safeAddress (deposit wallet users may strand funds in Safe).
    const provider = new ethers.providers.JsonRpcProvider(POLYMARKET_POLYGON_RPC_URL);
    const balanceAbi = ['function balanceOf(address) view returns (uint256)'];
    const queryAddresses = [polygonAddress];
    if (safeAddress && safeAddress !== polygonAddress) queryAddresses.push(safeAddress);

    const [stableBalances, positions] = await Promise.all([
      Promise.all(
        WITHDRAWABLE_STABLECOINS.map(async (token) => {
          const contract = new ethers.Contract(token.address, balanceAbi, provider);
          const bals: ethers.BigNumber[] = await Promise.all(
            queryAddresses.map((addr) => contract.balanceOf(addr))
          );
          const total = bals.reduce((acc, b) => acc.add(b), ethers.BigNumber.from(0));
          return { symbol: token.symbol, value: Number(ethers.utils.formatUnits(total, 6)) };
        })
      ),
      getPositions(polygonAddress, logKey).catch(() => [] as DataPosition[])
    ]);

    const onchain_idle = stableBalances.reduce((sum, b) => sum + b.value, 0);

    // Positions with curPrice >= 0.999 are in resolved markets where the user won.
    // Each must land in exactly ONE bucket, or totals double-count:
    //   - oracle finalized (payoutDenominator > 0) + CTF tokens held → claimable
    //     cash: goes to idle_usdc, excluded from positions_value.
    //   - oracle finalized + tokens gone → claim already done or in-flight; the
    //     payout sits in the wallet's stablecoin balance (onchain_idle), so the
    //     position counts NOWHERE. The Data API keeps listing it for a while
    //     after redemption, which otherwise inflates the total during a claim.
    //   - oracle not run yet → still just an active position (positions_value).
    const ctfAbi = [
      'function balanceOf(address, uint256) view returns (uint256)',
      'function payoutDenominator(bytes32) view returns (uint256)'
    ];
    const ctf = new ethers.Contract(CTF_ADDRESS, ctfAbi, provider);
    const winningCandidates = positions.filter((p) => (p.curPrice ?? 0) >= 0.999);
    const classified = await Promise.all(
      winningCandidates.map(async (p) => {
        try {
          const [bal, denom]: [ethers.BigNumber, ethers.BigNumber] = await Promise.all([
            ctf.balanceOf(polygonAddress, p.asset),
            ctf.payoutDenominator(p.conditionId)
          ]);
          if (denom.isZero()) return { position: p, bucket: 'active' as const };
          return {
            position: p,
            bucket: bal.isZero() ? ('settled' as const) : ('redeemable' as const)
          };
        } catch {
          return { position: p, bucket: 'redeemable' as const }; // RPC failure — optimistically claimable
        }
      })
    );

    const sumValues = (items: { position: DataPosition }[]): number =>
      items.reduce((sum, item) => sum + (item.position.currentValue || 0), 0);

    const redeemableItems = classified.filter((c) => c.bucket === 'redeemable');
    const redeemable = sumValues(redeemableItems);
    const notActive = sumValues(classified.filter((c) => c.bucket !== 'active'));

    const positions_value =
      positions.reduce((sum, p) => sum + (p.currentValue || 0), 0) - notActive;

    const idle_usdc = onchain_idle + redeemable;

    Logger.log(
      'info',
      fnLog,
      `${logKey} Polymarket balances — idle (${stableBalances
        .map((b) => `${b.symbol}: $${b.value.toFixed(2)}`)
        .join(
          ', '
        )}), redeemable: $${redeemable.toFixed(2)} (${redeemableItems.length}/${winningCandidates.length} winning claimable), positions: $${positions_value.toFixed(2)}`
    );

    return { idle_usdc, positions_value };
  } catch (error) {
    Logger.log('warn', fnLog, `${logKey} Failed to fetch Polymarket balances: ${String(error)}`);
    return { idle_usdc: 0, positions_value: 0 };
  }
}

/**
 * Synchronize all open orders on the Polymarket CLOB with our MongoDB.
 * Fetches from CLOB, compares against pending, updates MongoDB.
 */
export async function syncOpenOrders(
  user: IUser,
  privateKey: string,
  logKey: string
): Promise<void> {
  const fnLog = `[${LOG_PREFIX}:syncOpenOrders]`;
  try {
    Logger.log(
      'info',
      fnLog,
      `${logKey} Starting local vs remote order state reconciliation for user ${user.phone_number}`
    );

    // Fetch live open orders from CLOB
    const clobOrders = await getOpenOrders(user, privateKey, logKey);
    const liveOrderIds = new Set(
      clobOrders
        .map((o) => o.id || (o as any).orderID)
        .filter((id): id is string => {
          if (!id) {
            Logger.log('warn', fnLog, `${logKey} CLOB order missing both id and orderID fields`);
          }
          return !!id;
        })
    );

    // Fetch local pending orders from DB
    const localPendingOrders = await PolymarketOrderModel.find({
      user_phone: user.phone_number,
      status: 'pending'
    }).lean();

    const client = await getAuthenticatedClientForUser(user, privateKey);

    // Collect bulk updates instead of sequential saves
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const bulkOps: any[] = [];

    for (const pendingOrder of localPendingOrders) {
      // Still resting on the CLOB book — nothing to reconcile yet.
      if (liveOrderIds.has(pendingOrder.order_id)) continue;

      // No longer open on the CLOB. Defer the verdict while the fill is still
      // settling: a marketable order leaves the book instantly but its match is
      // recorded async, so an early read can falsely look cancelled/unfilled.
      const ageMs = Date.now() - new Date(pendingOrder.created_at).getTime();
      if (ageMs < ORDER_SYNC_GRACE_MS) {
        Logger.log(
          'info',
          fnLog,
          `${logKey} Order ${pendingOrder.order_id} placed ${Math.round(ageMs / 1000)}s ago — ` +
            `within grace window, deferring reconciliation.`
        );
        continue;
      }

      let newStatus: string | null = null;
      try {
        const orderData = await client.getOrder(pendingOrder.order_id);
        if (orderData) {
          const sizeMatched = Number((orderData as any).size_matched || 0);
          const associateTrades = (orderData as any).associate_trades;
          const hasFills =
            sizeMatched > 0 || (Array.isArray(associateTrades) && associateTrades.length > 0);
          const remoteStatus = String((orderData as any).status || '').toUpperCase();

          if (hasFills) {
            // The order executed and has left the book, so the fill is final —
            // no further matching is coming. Share counts are NOT comparable to
            // the requested size for marketable BUYs (USD-denominated, filled at
            // market price within FOK_SLIPPAGE_TOLERANCE), so a share-for-share
            // "fully filled" test spuriously reports partial. Any fill on an
            // off-book order means the trade went through → completed.
            newStatus = 'filled';
          } else if (
            remoteStatus === 'CANCELED' ||
            remoteStatus === 'CANCELLED' ||
            remoteStatus === 'UNMATCHED'
          ) {
            // No fills and a terminal cancel verdict → genuinely cancelled.
            newStatus = 'cancelled';
          }
        }
      } catch (getOrderError) {
        Logger.log(
          'warn',
          fnLog,
          `${logKey} Could not fetch closed order ${pendingOrder.order_id} from CLOB — leaving status unchanged.`
        );
      }

      // Inconclusive (unfetchable, or off-book with no fills and no explicit
      // cancel): leave it for a later sync rather than guessing.
      if (!newStatus) continue;

      bulkOps.push({
        updateOne: {
          filter: { _id: pendingOrder._id },
          update: { $set: { status: newStatus, updated_at: new Date() } }
        }
      });

      // Propagate the verdict onto the linked transaction-history record.
      await mongoTransactionService.updateStatusByPolymarketOrderId(
        pendingOrder.order_id,
        mapClobStatusToTxStatus(newStatus)
      );

      Logger.log(
        'info',
        fnLog,
        `${logKey} Synced order ${pendingOrder.order_id}: pending -> ${newStatus}`
      );
    }

    if (bulkOps.length > 0) {
      await PolymarketOrderModel.bulkWrite(bulkOps);
    }
    Logger.log(
      'info',
      fnLog,
      `${logKey} Reconciliation complete (${bulkOps.length} orders updated)`
    );
  } catch (error) {
    Logger.log('error', fnLog, `${logKey} Reconciliation failed: ${String(error)}`);
    throw new Error(`Failed to sync orders: ${String(error)}`);
  }
}
