import { Document, model, Schema } from 'mongoose';

export enum NotificationEnum {
  incoming_transfer = 'incoming_transfer',
  incoming_transfer_w_note = 'incoming_transfer_w_note',
  incoming_transfer_external = 'incoming_transfer_external',
  swap = 'swap',
  mint = 'mint',
  outgoing_transfer = 'outgoing_transfer',
  wallet_creation = 'wallet_creation',
  wallet_creation_intro = 'wallet_creation_intro',
  wallet_already_exists = 'wallet_already_exists',
  wallet_already_exists_intro = 'wallet_already_exists_intro',
  user_balance_not_enough = 'user_balance_not_enough',
  no_valid_blockchain_conditions = 'no_valid_blockchain_conditions',
  internal_error = 'internal_error',
  concurrent_operation = 'concurrent_operation',
  daily_limit_reached = 'daily_limit_reached',
  amount_outside_limits = 'amount_outside_limits',
  aave_supply_created = 'aave_supply_created',
  aave_supply_info = 'aave_supply_info',
  aave_supply_info_no_data = 'aave_supply_info_no_data',
  aave_supply_modified = 'aave_supply_modified',
  chatterpoints_operation = 'chatterpoints_operation',
  deposit_from_other_networks = 'deposit_from_other_networks',
  deposit_info_intro = 'deposit_info_intro',
  wallet_next_steps = 'wallet_next_steps',
  cross_chain_disabled = 'cross_chain_disabled',
  polymarket_order_placed = 'polymarket_order_placed',
  polymarket_order_failed = 'polymarket_order_failed',
  polymarket_terms_not_accepted = 'polymarket_terms_not_accepted',
  polymarket_disabled = 'polymarket_disabled',
  polymarket_settlement_claimed = 'polymarket_settlement_claimed',
  polymarket_account_created = 'polymarket_account_created',
  polymarket_order_cancelled = 'polymarket_order_cancelled',
  polymarket_account_not_found = 'polymarket_account_not_found',
  polymarket_bridge_initiated = 'polymarket_bridge_initiated',
  polymarket_terms_request = 'polymarket_terms_request',
  pin_not_set = 'pin_not_set',
  pin_invalid_remaining_attempts = 'pin_invalid_remaining_attempts',
  pin_blocked = 'pin_blocked',
  pin_verified_success = 'pin_verified_success',
  pin_internal_error = 'pin_internal_error',
  operation_in_progress = 'operation_in_progress',
  wallet_not_created = 'wallet_not_created',
  cardano_amount_below_minimum = 'cardano_amount_below_minimum',
  cardano_insufficient_ada = 'cardano_insufficient_ada',
  cardano_change_carries_tokens = 'cardano_change_carries_tokens',
  cardano_change_below_floor = 'cardano_change_below_floor',
  cardano_token_needs_ada = 'cardano_token_needs_ada',
  cardano_token_needs_ada_keeping_rest = 'cardano_token_needs_ada_keeping_rest',
  cardano_token_change_needs_ada = 'cardano_token_change_needs_ada',
  cardano_token_balance_not_enough = 'cardano_token_balance_not_enough',
  cardano_amount_below_fee = 'cardano_amount_below_fee',
  cardano_sponsor_unavailable = 'cardano_sponsor_unavailable',
  cardano_fee_price_unavailable = 'cardano_fee_price_unavailable',
  cardano_insufficient_funds = 'cardano_insufficient_funds',
  user_blocked = 'user_blocked'
}

export interface LocalizedContentType {
  en: string;
  es: string;
  pt: string;
}

export interface NotificationUtilityConfigType {
  enabled: boolean;
  template_key: string;
  param_order: string[];
}

export interface NotificationButtonType {
  id: string;
  title: LocalizedContentType;
}

export interface NotificationTemplateType {
  title: LocalizedContentType;
  message: LocalizedContentType;
  footer?: LocalizedContentType;
  button?: LocalizedContentType;
  buttons?: NotificationButtonType[];
  utility?: NotificationUtilityConfigType;
}

export type NotificationTemplatesTypes = {
  [key in NotificationEnum]: NotificationTemplateType;
};

/**
 * A site-wide announcement rendered by the front as a one-line banner.
 *
 * Visibility is data, not code: an item shows while `enabled` is true and the current instant sits
 * between `initAt` and `endAt`, so an announcement can be scheduled ahead of time and stops showing
 * on its own without a deploy. `title` is the single line the banner shows collapsed; `message` is
 * the full text behind the expander, and is also what the notification and WhatsApp scripts send.
 *
 * `showInLanding` and `showInDashboard` pick the surfaces the item reaches. Both are optional and
 * an absent flag counts as visible, so an announcement written before the flags existed keeps
 * showing everywhere it used to.
 */
export interface NewsItemType {
  title: LocalizedContentType;
  message: LocalizedContentType;
  enabled: boolean;
  showInLanding?: boolean;
  showInDashboard?: boolean;
  order: number;
  createdAt: Date;
  initAt: Date;
  endAt: Date;
}

export type NewsTemplatesTypes = Record<string, NewsItemType>;

export interface ITemplateSchema extends Document {
  notifications: {
    [key in NotificationEnum]: NotificationTemplateType;
  };
  security_questions: Record<string, LocalizedContentType>;
  news: NewsTemplatesTypes;
}

const localizedContentSchema = new Schema<LocalizedContentType>({
  en: { type: String, required: true },
  es: { type: String, required: true },
  pt: { type: String, required: true }
});

const notificationButtonSchema = new Schema<NotificationButtonType>(
  {
    id: { type: String, required: true },
    title: { type: localizedContentSchema, required: true }
  },
  { _id: false }
);

const notificationSchema = new Schema<NotificationTemplateType>({
  title: { type: localizedContentSchema, required: true },
  message: { type: localizedContentSchema, required: true },
  footer: { type: localizedContentSchema, required: false },
  button: { type: localizedContentSchema, required: false },
  buttons: { type: [notificationButtonSchema], required: false },
  utility: {
    type: new Schema<NotificationUtilityConfigType>(
      {
        enabled: { type: Boolean, required: true },
        template_key: { type: String, required: true },
        param_order: { type: [String], required: true }
      },
      { _id: false }
    ),
    required: false
  }
});

const newsSchema = new Schema<NewsItemType>(
  {
    title: { type: localizedContentSchema, required: true },
    message: { type: localizedContentSchema, required: true },
    enabled: { type: Boolean, required: true, default: true },
    showInLanding: { type: Boolean, required: false, default: true },
    showInDashboard: { type: Boolean, required: false, default: true },
    order: { type: Number, required: false, default: 0 },
    createdAt: { type: Date, required: true, default: Date.now },
    initAt: { type: Date, required: true },
    endAt: { type: Date, required: true }
  },
  { _id: false }
);

const templateSchema = new Schema<ITemplateSchema>({
  notifications: {
    incoming_transfer: { type: notificationSchema, required: true },
    incoming_transfer_w_note: { type: notificationSchema, required: true },
    incoming_transfer_external: { type: notificationSchema, required: true },
    swap: { type: notificationSchema, required: true },
    mint: { type: notificationSchema, required: true },
    outgoing_transfer: { type: notificationSchema, required: true },
    wallet_creation: { type: notificationSchema, required: true },
    wallet_creation_intro: { type: notificationSchema, required: true },
    wallet_already_exists: { type: notificationSchema, required: true },
    wallet_already_exists_intro: { type: notificationSchema, required: true },
    user_balance_not_enough: { type: notificationSchema, required: true },
    no_valid_blockchain_conditions: { type: notificationSchema, required: true },
    concurrent_operation: { type: notificationSchema, required: true },
    internal_error: { type: notificationSchema, required: true },
    daily_limit_reached: { type: notificationSchema, required: true },
    amount_outside_limits: { type: notificationSchema, required: true },
    aave_supply_created: { type: notificationSchema, required: true },
    aave_supply_modified: { type: notificationSchema, required: true },
    aave_supply_info: { type: notificationSchema, required: true },
    aave_supply_info_no_data: { type: notificationSchema, required: true },
    chatterpoints_operation: { type: notificationSchema, required: true },
    deposit_from_other_networks: { type: notificationSchema, required: true },
    deposit_info_intro: { type: notificationSchema, required: true },
    wallet_next_steps: { type: notificationSchema, required: true },
    cross_chain_disabled: { type: notificationSchema, required: true },
    polymarket_order_placed: { type: notificationSchema, required: false },
    polymarket_order_failed: { type: notificationSchema, required: false },
    polymarket_terms_not_accepted: { type: notificationSchema, required: false },
    polymarket_disabled: { type: notificationSchema, required: false },
    polymarket_settlement_claimed: { type: notificationSchema, required: false },
    polymarket_account_created: { type: notificationSchema, required: false },
    polymarket_order_cancelled: { type: notificationSchema, required: false },
    polymarket_account_not_found: { type: notificationSchema, required: false },
    polymarket_bridge_initiated: { type: notificationSchema, required: false },
    polymarket_terms_request: { type: notificationSchema, required: false },
    pin_not_set: { type: notificationSchema, required: true },
    pin_invalid_remaining_attempts: { type: notificationSchema, required: true },
    pin_blocked: { type: notificationSchema, required: true },
    pin_verified_success: { type: notificationSchema, required: true },
    pin_internal_error: { type: notificationSchema, required: true },
    operation_in_progress: { type: notificationSchema, required: true },
    wallet_not_created: { type: notificationSchema, required: true },
    // Optional like the polymarket ones: the code ships with an English fallback, so a document
    // written before the templates were loaded still saves.
    cardano_amount_below_minimum: { type: notificationSchema, required: false },
    cardano_insufficient_ada: { type: notificationSchema, required: false },
    cardano_change_carries_tokens: { type: notificationSchema, required: false },
    cardano_change_below_floor: { type: notificationSchema, required: false },
    cardano_token_needs_ada: { type: notificationSchema, required: false },
    cardano_token_needs_ada_keeping_rest: { type: notificationSchema, required: false },
    cardano_token_change_needs_ada: { type: notificationSchema, required: false },
    cardano_token_balance_not_enough: { type: notificationSchema, required: false },
    cardano_amount_below_fee: { type: notificationSchema, required: false },
    cardano_sponsor_unavailable: { type: notificationSchema, required: false },
    cardano_fee_price_unavailable: { type: notificationSchema, required: false },
    cardano_insufficient_funds: { type: notificationSchema, required: false },
    user_blocked: { type: notificationSchema, required: false }
  },
  security_questions: { type: Map, of: localizedContentSchema, required: false },
  news: { type: Map, of: newsSchema, required: false }
});

export const TemplateType = model<ITemplateSchema>('Template', templateSchema, 'templates');
