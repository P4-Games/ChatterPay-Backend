import type { ethers } from 'ethers';

/**
 * Basic token information including price
 */
export interface TokenInfo {
  symbol: string;
  address: string;
  type: string;
  rateUSD: number;
  display_decimals: number;
  display_symbol: string;
}

/**
 * Supported fiat currencies for conversion
 */
export type Currency = 'USD' | 'UYU' | 'ARS' | 'BRL';

/**
 * Fiat currency quote information
 */
export interface FiatQuote {
  currency: Currency;
  rate: number;
}

/**
 * Token information including balance
 */
export interface TokenBalance extends TokenInfo {
  balance: string;
}

/**
 * Detailed balance information for a token including conversions
 */
export interface BalanceInfo {
  network: string;
  token: string;
  tokenAddress?: string;
  balance: number;
  balance_conv: Record<Currency, number>;
}

export interface WalletBalanceInfo {
  walletBalance: string;
  amountToCheck: string;
  enoughBalance: boolean;
}

export interface CheckBalanceConditionsResult {
  success: boolean;
  setupContractsResult: SetupContractReturn | null;
  entryPointContract: ethers.Contract | null;
}

export interface swapTokensData {
  tokenInputAddress: string;
  tokenInputSymbol: string;
  tokenInputDisplaySymbol: string;
  tokenInputDisplayDecimals: number;
  tokenOutputAddress: string;
  tokenOutputSymbol: string;
  tokenOutputDisplaySymbol: string;
  tokenOutputDisplayDecimals: number;
}

export interface ExecuteSwapResult {
  success: boolean;
  approveTransactionHash: string;
  swapTransactionHash: string;
  /** Li.Fi-specific details when swap was executed via Li.Fi aggregator */
  lifiDetails?: {
    quoteId: string;
    tool: string;
    toAmountMin: string;
  };
}

export interface ExecueTransactionResult {
  success: boolean;
  transactionHash: string;
  error: string;
}

export interface SetupContractReturn {
  provider: ethers.providers.JsonRpcProvider;
  userPrincipal: ethers.Wallet;
  backPrincipal: ethers.Wallet;
  chatterPay: ethers.Contract;
  proxy: ComputedAddress;
  accountExists: boolean;
}

export enum ConcurrentOperationsEnum {
  Transfer = 'transfer',
  Swap = 'swap',
  MintNft = 'mint_nft',
  MintNftCopy = 'mint_nft_copy'
}

export interface TransactionData {
  tx: string;
  walletFrom: string;
  walletTo: string;
  amount: number;
  fee: number;
  token: string;
  type: string;
  status: string;
  chain_id: number;
  date?: Date;
  user_notes?: string;
  /**
   * Network fee the chain charged, in its own coin. Distinct from `fee`, which is the ChatterPay
   * fee taken in the token being moved. On EVM the paymaster absorbs the network cost and the user
   * never sees it; on Cardano the sender pays it directly out of their own inputs.
   */
  network_fee?: number;
  /** Coin `network_fee` is denominated in, e.g. `ADA`. */
  network_fee_token?: string;
  /**
   * ADA the ledger forced to travel with a token, on a Cardano token transfer.
   *
   * Not a fee: the recipient keeps it. Recorded because it is the only figure that explains why
   * sending a token also moved ADA.
   */
  attached_ada?: number;
  polymarket_order_id?: string;
  polymarket_purchase_id?: string;
  polymarket_market_slug?: string;
  /** Number of shares bought/sold (Polymarket orders only). */
  polymarket_size?: number;
  /**
   * Polymarket BUY — bridge sub-step data (Scroll → Polygon).
   * Stored inline on the buy record so the bridge is a detail of the
   * purchase, not a separate history row.
   */
  polymarket_bridge_tx_hash?: string;
  /** Amount (human-readable) that left the user's Scroll wallet for the bridge. */
  polymarket_bridge_amount?: number;
  /** Scroll-side stablecoin used for the bridge (e.g. 'USDT', 'USDC'). */
  polymarket_bridge_token?: string;
}

export interface ConversionRates {
  [token: string]: {
    [currency: string]: number;
  };
}

export interface MintResult {
  tokenAddress: string;
  txHash: string;
}

export interface UserPrincipal {
  data: string;
  EOAAddress: string;
}

export interface ComputedAddress extends UserPrincipal {
  proxyAddress: string;
}

export const rpcProviders = {
  ALCHEMY: 'alchemy',
  PIMLICO: 'pimlico'
} as const;

export type RpcProvider = (typeof rpcProviders)[keyof typeof rpcProviders];

export enum CacheNames {
  OPENSEA = 'openSea',
  PRICE = 'priceCache',
  ABI = 'abiCache',
  NOTIFICATION = 'notificationTemplateCache',
  TOR = 'torCache',
  COINGECKO = 'coingeckoCache',
  FIAT = 'fiatCache',
  ERC20 = 'erc20',
  CHATTERPOINTS_WORDS = 'chatterpoints_words'
}

const systemLanguages = ['en', 'es', 'pt'] as const;

export const notificationLanguages = systemLanguages;
export type NotificationLanguage = (typeof notificationLanguages)[number];

export const gamesLanguages = systemLanguages;
export type gamesLanguage = (typeof gamesLanguages)[number];

export type AddressBalanceWithNfts = {
  balances: BalanceInfo[];
  totals: Record<Currency, number>;
  certificates: unknown[];
  wallets: string[];
  polymarket?: {
    idle_usdc: number;
    positions_value: number;
    total_usd: number;
  };
};
