import { ethers } from 'ethers';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { Logger } from '../helpers/loggerHelper';
import {
  returnErrorResponse,
  returnErrorResponseAsSuccess,
  returnSuccessResponse
} from '../helpers/requestHelper';
import { delaySeconds } from '../helpers/timeHelper';
import { isValidPhoneNumber } from '../helpers/validationHelper';
import { NotificationEnum } from '../models/templateModel';
import type { IUser, IUserWallet } from '../models/userModel';
import { buildTokenAddressMap, getTokenPrices } from '../services/balanceService';
import {
  checkBlockchainConditions,
  getSwapTokensData,
  userReachedOperationLimit,
  userWithinTokenOperationLimits
} from '../services/blockchainService';
import {
  chatterpointsService,
  type RegisterOperationResult
} from '../services/chatterpointsService';
import { getChatterpayTokenFee } from '../services/commonService';
import { mongoTransactionService } from '../services/mongo/mongoTransactionService';
import { mongoUserService } from '../services/mongo/mongoUserService';
import {
  getNotificationTemplate,
  persistNotification,
  sendInternalErrorNotification,
  sendNoValidBlockchainConditionsNotification,
  sendSwapNotification,
  sendUserInsufficientBalanceNotification
} from '../services/notificationService';
import { secService } from '../services/secService';
import { securityService } from '../services/securityService';
import { executeSwap } from '../services/swapService';
import {
  closeOperation,
  getUser,
  getUserWalletByChainId,
  hasPhoneAnyOperationInProgress,
  openOperation
} from '../services/userService';
import { setupERC20 } from '../services/web3/contractSetupService';
import {
  type CheckBalanceConditionsResult,
  ConcurrentOperationsEnum,
  type ExecuteSwapResult,
  type swapTokensData,
  type TransactionData
} from '../types/commonType';

interface SwapBody {
  channel_user_id: string;
  user_wallet: string;
  inputCurrency: string;
  outputCurrency: string;
  amount: number;
}

/**
 * Validates the input for the swap operation.
 *
 * @param inputs - The input data for the swap.
 * @param tokenAddresses - The token addresses for the input and output currencies.
 * @returns A string indicating the validation error, or an empty string if validation passes.
 */
const validateInputs = async (
  inputs: SwapBody,
  tokenAddresses: swapTokensData
): Promise<string> => {
  const { channel_user_id, inputCurrency, outputCurrency, amount } = inputs;

  if (!channel_user_id || !inputCurrency || !outputCurrency) {
    return 'Missing required fields: address, inputCurrency, or outputCurrency';
  }

  if (!isValidPhoneNumber(channel_user_id)) {
    return `'${channel_user_id}' is invalid. 'channel_user_id' parameter must be a phone number (without spaces or symbols)`;
  }

  if (inputCurrency === outputCurrency) {
    return 'Input and output currencies must be different';
  }

  if (amount === undefined || amount <= 0) {
    return 'Amount must be provided and greater than 0';
  }

  if (!tokenAddresses.tokenInputAddress || !tokenAddresses.tokenOutputAddress) {
    return 'Invalid token symbols for the current network';
  }

  return '';
};

/**
 * Handles the swap operation.
 *
 * @param request - The request object containing the swap details.
 * @param reply - The response object used to send the response.
 * @returns A response indicating the status of the swap.
 */
// eslint-disable-next-line consistent-return
export const swap = async (
  request: FastifyRequest<{ Body: SwapBody; Querystring?: { lastBotMsgDelaySeconds?: number } }>,
  reply: FastifyReply
  // eslint-disable-next-line consistent-return
) => {
  let logKey = `[op:swap:${''}:${''}:${''}:${''}]`;

  try {
    /* ***************************************************** */
    /* 1. swap: input params                                 */
    /* ***************************************************** */
    if (!request.body) {
      return await returnErrorResponse(
        'swap',
        logKey,
        reply,
        400,
        'You have to send a body with this request'
      );
    }

    const { channel_user_id, inputCurrency, outputCurrency, amount } = request.body;
    const lastBotMsgDelaySeconds = request.query?.lastBotMsgDelaySeconds ?? 0;
    const { tokens: blockchainTokens, networkConfig } = request.server as FastifyInstance;

    logKey = `[op:swap:${channel_user_id}:${inputCurrency}:${outputCurrency}:${amount}]`;

    const tokensData: swapTokensData = getSwapTokensData(
      networkConfig,
      blockchainTokens,
      inputCurrency,
      outputCurrency
    );

    let validationError: string = await validateInputs(request.body, tokensData);

    if (validationError) {
      Logger.error('swap', logKey, `Invalid swap request: ${validationError}`);
      // must return 200, so the bot displays the message instead of staying silent!
      return await returnErrorResponseAsSuccess(
        'swap',
        logKey,
        reply,
        'Error making swap',
        false,
        channel_user_id,
        validationError
      );
    }

    /* ***************************************************** */
    /* 2. swap: check user has wallet                        */
    /* ***************************************************** */
    const fromUser: IUser | null = await getUser(channel_user_id);
    if (!fromUser) {
      const { message: walletNotCreatedMessage } = await getNotificationTemplate(
        channel_user_id,
        NotificationEnum.wallet_not_created
      );
      Logger.info('swap', logKey, walletNotCreatedMessage);
      // must return 200, so the bot displays the message instead of an error!
      return await returnSuccessResponse(reply, walletNotCreatedMessage);
    }

    /* ***************************************************** */
    /* 3. swap: check operation limit                        */
    /* ***************************************************** */
    const userReachedOpLimit = await userReachedOperationLimit(
      request.server.networkConfig,
      channel_user_id,
      'swap'
    );
    if (userReachedOpLimit) {
      const { message } = await getNotificationTemplate(
        channel_user_id,
        NotificationEnum.daily_limit_reached
      );

      await persistNotification(channel_user_id, message, NotificationEnum.daily_limit_reached);

      Logger.info('swap', logKey, `${message}`);
      // must return 200, so the bot displays the message instead of an error!
      return await returnSuccessResponse(reply, message);
    }

    /* ***************************************************** */
    /* 3.1. swap: check security gate                        */
    /* ***************************************************** */
    const operationGate = await securityService.getOperationGate(channel_user_id);
    if (!operationGate.allowed) {
      return await returnSuccessResponse(reply, 'Security verification required', {
        allowed: false,
        required_flow: operationGate.required_flow,
        reason: operationGate.reason,
        blocked_until: operationGate.blocked_until
      });
    }

    /* ***************************************************** */
    /* 4. makeTransaction: check amount limit                */
    /* ***************************************************** */
    const limitsResult = await userWithinTokenOperationLimits(
      channel_user_id,
      'swap',
      inputCurrency,
      networkConfig.chainId,
      amount
    );
    if (!limitsResult.isWithinLimits) {
      const { message } = await getNotificationTemplate(
        channel_user_id,
        NotificationEnum.amount_outside_limits
      );
      const formattedMessage = message
        .replace('[LIMIT_MIN]', limitsResult.min!.toString())
        .replace('[LIMIT_MAX]', limitsResult.max!.toString());
      Logger.info('swap', logKey, `${formattedMessage}`);

      await persistNotification(
        channel_user_id,
        formattedMessage,
        NotificationEnum.amount_outside_limits
      );

      // must return 200, so the bot displays the message instead of an error!
      return await returnSuccessResponse(reply, formattedMessage);
    }

    /* ***************************************************** */
    /* 5. swap: check concurrent operation                    */
    /* ***************************************************** */
    const userOperations = await hasPhoneAnyOperationInProgress(channel_user_id);
    if (userOperations) {
      const { message } = await getNotificationTemplate(
        channel_user_id,
        NotificationEnum.concurrent_operation
      );
      await persistNotification(channel_user_id, message, NotificationEnum.concurrent_operation);

      validationError = `Concurrent swap operation for phone: ${channel_user_id}.`;
      Logger.log(`swap', ${logKey}, ${validationError}`);
      // must return 200, so the bot displays the message instead of an error!
      return await returnSuccessResponse(reply, message);
    }

    /* ***************************************************** */
    /* 6. swap: send initial response                        */
    /* ***************************************************** */
    // optimistic response
    await openOperation(channel_user_id, ConcurrentOperationsEnum.Swap);
    Logger.log('swap', logKey, 'sending notification: operation in progress');
    const { message: operationInProgressMessage } = await getNotificationTemplate(
      channel_user_id,
      NotificationEnum.operation_in_progress
    );
    await returnSuccessResponse(reply, operationInProgressMessage);

    /* ***************************************************** */
    /* 7. swap: check user balance                           */
    /* ***************************************************** */
    const provider = new ethers.providers.JsonRpcProvider(networkConfig.rpc);
    const bs = secService.get_bs(provider);
    const userWallet: IUserWallet | null = getUserWalletByChainId(
      fromUser.wallets,
      networkConfig.chainId
    );
    if (!userWallet) {
      await closeOperation(channel_user_id, ConcurrentOperationsEnum.Swap);
      return await returnErrorResponse(
        'swap',
        logKey,
        reply,
        400,
        `Wallet not found for user ${channel_user_id} and chain ${networkConfig.chainId}`
      );
    }
    const proxyAddress = userWallet.wallet_proxy;

    // Get the contracts and decimals for the tokens
    const fromTokenContract = await setupERC20(tokensData.tokenInputAddress, bs);
    const fromTokenDecimals = await fromTokenContract.decimals();

    const toTokenContract = await setupERC20(tokensData.tokenOutputAddress, bs);
    const toTokenDecimals = await toTokenContract.decimals();

    // Get the current balances before the transaction
    const fromTokenCurrentBalance = await fromTokenContract.balanceOf(proxyAddress);
    const toTokenCurrentBalance = await toTokenContract.balanceOf(proxyAddress);

    const amountToCheck = ethers.utils.parseUnits(amount.toString(), fromTokenDecimals);
    const enoughBalance: boolean = fromTokenCurrentBalance.gte(amountToCheck);

    if (!enoughBalance) {
      validationError = `Insufficient balance, phone: ${channel_user_id}, wallet: ${proxyAddress}. Required: ${toTokenCurrentBalance}, Available: ${fromTokenCurrentBalance}.`;
      Logger.info('swap', logKey, validationError);
      await sendUserInsufficientBalanceNotification(proxyAddress, channel_user_id);
      await closeOperation(channel_user_id, ConcurrentOperationsEnum.Swap);
      return undefined;
    }

    /* ***************************************************** */
    /* 8. swap: check blockchain conditions                  */
    /* ***************************************************** */
    const checkBlockchainConditionsResult: CheckBalanceConditionsResult =
      await checkBlockchainConditions(networkConfig, fromUser);

    if (!checkBlockchainConditionsResult.success) {
      await sendNoValidBlockchainConditionsNotification(proxyAddress, channel_user_id);
      await closeOperation(channel_user_id, ConcurrentOperationsEnum.Swap);
      return undefined;
    }

    /* ***************************************************** */
    /* 9. swap: make operation                               */
    /* ***************************************************** */
    const executeSwapResult: ExecuteSwapResult = await executeSwap(
      networkConfig,
      checkBlockchainConditionsResult.setupContractsResult!,
      checkBlockchainConditionsResult.entryPointContract!,
      tokensData,
      blockchainTokens,
      amount.toString(),
      proxyAddress,
      logKey
    );
    if (!executeSwapResult.success) {
      await sendInternalErrorNotification(channel_user_id, lastBotMsgDelaySeconds);
      await closeOperation(channel_user_id, ConcurrentOperationsEnum.Swap);
      return undefined;
    }

    /* ***************************************************** */
    /* 10. swap: update database with result                  */
    /* ***************************************************** */
    // Get the new balances after the transaction
    const fromTokenNewBalance = await fromTokenContract.balanceOf(proxyAddress);
    const toTokenNewBalance = await toTokenContract.balanceOf(proxyAddress);

    // Calculate the tokens sent and received, considering the correct decimals
    const fromTokensSent = fromTokenCurrentBalance.sub(fromTokenNewBalance);
    const toTokensReceived = toTokenNewBalance.sub(toTokenCurrentBalance);

    // Normalize balances to human units
    const fromTokensSentNormalized = ethers.utils.formatUnits(fromTokensSent, fromTokenDecimals);
    const toTokensReceivedNormalized = ethers.utils.formatUnits(toTokensReceived, toTokenDecimals);

    // Apply display_decimals for DB (numbers) and notifications (strings)
    const fromTokensSentInUnits = parseFloat(
      parseFloat(fromTokensSentNormalized).toFixed(tokensData.tokenInputDisplayDecimals)
    );
    const toTokensReceivedInUnits = parseFloat(
      parseFloat(toTokensReceivedNormalized).toFixed(tokensData.tokenOutputDisplayDecimals)
    );

    // String versions for notifications (preserve trailing zeros)
    const fromTokensSentDisplay = parseFloat(fromTokensSentNormalized).toFixed(
      tokensData.tokenInputDisplayDecimals
    );
    const toTokensReceivedDisplay = parseFloat(toTokensReceivedNormalized).toFixed(
      tokensData.tokenOutputDisplayDecimals
    );

    const chatterpayFee = await getChatterpayTokenFee(
      proxyAddress,
      checkBlockchainConditionsResult.setupContractsResult!.provider,
      tokensData.tokenInputAddress
    );

    // Save transactions OUT
    Logger.log('swap', logKey, 'Updating swap transactions in database.');
    const transactionOut: TransactionData = {
      tx: executeSwapResult.swapTransactionHash || '0x',
      walletFrom: proxyAddress,
      walletTo: networkConfig.contracts.routerAddress!,
      amount: fromTokensSentInUnits,
      fee: chatterpayFee,
      token: inputCurrency,
      type: 'swap',
      status: 'completed',
      chain_id: request.server.networkConfig.chainId
    };
    await mongoTransactionService.saveTransaction(transactionOut);

    // Save transactions IN
    const transactionIn: TransactionData = {
      tx: executeSwapResult.swapTransactionHash || '0x',
      walletFrom: networkConfig.contracts.routerAddress!,
      walletTo: proxyAddress,
      amount: toTokensReceivedInUnits,
      fee: 0, // no fee in token out
      token: outputCurrency,
      type: 'swap',
      status: 'completed',
      chain_id: request.server.networkConfig.chainId
    };
    await mongoTransactionService.saveTransaction(transactionIn);

    await mongoUserService.updateUserOperationCounter(channel_user_id, 'swap');

    /* ***************************************************** */
    /* 11. swap: Chatterpoints Operation                     */
    /* ***************************************************** */
    // The address map matters: without it a token Binance does not list (SCR, wstETH) prices at
    // nothing and the operation is registered as a zero-dollar swap.
    const prices = await getTokenPrices(
      [inputCurrency],
      buildTokenAddressMap(blockchainTokens, networkConfig.chainId),
      networkConfig.chainId
    );
    const price = prices.get(inputCurrency.toUpperCase()) ?? 1;
    const amountInUsd = toTokensReceivedInUnits * price;

    const chatterpointsOpResult: RegisterOperationResult | null =
      await chatterpointsService.registerOperation({
        userId: fromUser.phone_number,
        userLevel: fromUser.level,
        type: ConcurrentOperationsEnum.Swap,
        amount: amountInUsd,
        operationId: executeSwapResult.swapTransactionHash
      });

    /* ***************************************************** */
    /* 12. swap: send notification to user                   */
    /* ***************************************************** */

    await closeOperation(channel_user_id, ConcurrentOperationsEnum.Swap);

    if (lastBotMsgDelaySeconds > 0) {
      Logger.log('swap', logKey, `Delaying bot notification ${lastBotMsgDelaySeconds} seconds.`);
      await delaySeconds(lastBotMsgDelaySeconds);
    }
    await sendSwapNotification(
      channel_user_id,
      tokensData.tokenInputSymbol,
      fromTokensSentDisplay,
      toTokensReceivedDisplay,
      tokensData.tokenOutputSymbol,
      executeSwapResult.swapTransactionHash,
      chatterpointsOpResult
    );

    Logger.info(
      'swap',
      logKey,
      `Swap completed successfully approveTransactionHash: ${executeSwapResult.approveTransactionHash}, swapTransactionHash: ${executeSwapResult.swapTransactionHash}.`
    );
  } catch (error) {
    Logger.error('swap', logKey, error);
  }
};
