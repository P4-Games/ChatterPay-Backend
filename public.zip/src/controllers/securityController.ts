import type { FastifyReply, FastifyRequest } from 'fastify';
import { Logger } from '../helpers/loggerHelper';
import {
  returnErrorResponse,
  returnErrorResponseAsSuccess,
  returnSuccessResponse
} from '../helpers/requestHelper';
import { isValidPhoneNumber } from '../helpers/validationHelper';
import type { SecurityEventChannel, SecurityEventType } from '../models/securityEventModel';
import { NotificationEnum } from '../models/templateModel';
import type { IUser } from '../models/userModel';
import { getNotificationTemplate } from '../services/notificationService';
import { securityService } from '../services/securityService';
import { getUser } from '../services/userService';

const VALID_SECURITY_EVENT_CHANNELS: SecurityEventChannel[] = ['bot', 'frontend'];
const VALID_SECURITY_EVENT_TYPES: SecurityEventType[] = [
  'PIN_SET',
  'PIN_RESET',
  'PIN_RESET_FAILED',
  'QUESTIONS_SET',
  'QUESTIONS_UPDATED',
  'PIN_VERIFY_FAILED',
  'PIN_BLOCKED'
];

export const getSecurityStatus = async (
  request: FastifyRequest<{ Body: { channel_user_id: string } }>,
  reply: FastifyReply
): Promise<FastifyReply> => {
  const logKey = '[op:getSecurityStatus]';
  try {
    if (!request.body) {
      return await returnErrorResponse(
        'getSecurityStatus',
        logKey,
        reply,
        400,
        'You have to send a body with this request'
      );
    }

    const { channel_user_id } = request.body;

    if (!channel_user_id || !isValidPhoneNumber(channel_user_id)) {
      return await returnErrorResponseAsSuccess(
        'getReferralCodeWithUsageCount',
        logKey,
        reply,
        'Missing channel_user_id in body',
        false,
        channel_user_id,
        `'${channel_user_id}' is invalid. 'channel_user_id' parameter must be a phone number (without spaces or symbols)`
      );
    }

    const user: IUser | null = await getUser(channel_user_id);
    if (!user) {
      const { message } = await getNotificationTemplate(
        channel_user_id,
        NotificationEnum.wallet_not_created
      );
      Logger.info('getSecurityStatus', message);
      return await returnSuccessResponse(reply, message);
    }

    const status = await securityService.getSecurityStatus(channel_user_id);

    return await returnSuccessResponse(reply, 'Security status fetched successfully', {
      ...status
    });
  } catch (error) {
    return returnErrorResponse('getSecurityStatus', logKey, reply, 500, 'Internal Server Error');
  }
};

export const getSecurityQuestions = async (
  request: FastifyRequest<{ Body: { channel_user_id: string } }>,
  reply: FastifyReply
): Promise<FastifyReply> => {
  const logKey = '[op:getSecurityQuestions]';
  try {
    if (!request.body) {
      return await returnErrorResponse(
        'getSecurityStatus',
        logKey,
        reply,
        400,
        'You have to send a body with this request'
      );
    }

    const { channel_user_id } = request.body;

    if (!channel_user_id || !isValidPhoneNumber(channel_user_id)) {
      return await returnErrorResponseAsSuccess(
        'getReferralCodeWithUsageCount',
        logKey,
        reply,
        'Missing channel_user_id in body',
        false,
        channel_user_id,
        `'${channel_user_id}' is invalid. 'channel_user_id' parameter must be a phone number (without spaces or symbols)`
      );
    }

    const user: IUser | null = await getUser(channel_user_id);
    if (!user) {
      const { message } = await getNotificationTemplate(
        channel_user_id,
        NotificationEnum.wallet_not_created
      );
      Logger.info('getSecurityStatus', message);
      return await returnSuccessResponse(reply, message);
    }

    const questions = await securityService.listSecurityQuestions(
      user.settings?.notifications.language,
      channel_user_id
    );

    return await returnSuccessResponse(reply, 'Security questions fetched successfully', {
      questions
    });
  } catch (error) {
    return returnErrorResponse('getSecurityQuestions', logKey, reply, 500, 'Internal Server Error');
  }
};

export const getSecurityEvents = async (
  request: FastifyRequest<{
    Body: {
      channel_user_id: string;
      channel?: SecurityEventChannel;
      event_type?: SecurityEventType;
      eventt_type?: SecurityEventType;
    };
  }>,
  reply: FastifyReply
): Promise<FastifyReply> => {
  const logKey = '[op:getSecurityEvents]';
  try {
    if (!request.body) {
      return await returnErrorResponse(
        'getSecurityEvents',
        logKey,
        reply,
        400,
        'You have to send a body with this request'
      );
    }

    const { channel_user_id, channel, event_type, eventt_type } = request.body;
    const resolvedEventType = event_type ?? eventt_type;

    if (!channel_user_id || !isValidPhoneNumber(channel_user_id)) {
      return await returnErrorResponseAsSuccess(
        'getSecurityEvents',
        logKey,
        reply,
        'Missing channel_user_id in body',
        false,
        channel_user_id,
        `'${channel_user_id}' is invalid. 'channel_user_id' parameter must be a phone number (without spaces or symbols)`
      );
    }

    if (channel && !VALID_SECURITY_EVENT_CHANNELS.includes(channel)) {
      return await returnErrorResponseAsSuccess(
        'getSecurityEvents',
        logKey,
        reply,
        'Invalid channel in body',
        false,
        channel_user_id,
        `Invalid channel '${channel}'. Allowed values: bot, frontend.`
      );
    }

    if (resolvedEventType && !VALID_SECURITY_EVENT_TYPES.includes(resolvedEventType)) {
      return await returnErrorResponseAsSuccess(
        'getSecurityEvents',
        logKey,
        reply,
        'Invalid event_type in body',
        false,
        channel_user_id,
        `Invalid event_type '${resolvedEventType}'.`
      );
    }

    const user: IUser | null = await getUser(channel_user_id);
    if (!user) {
      const { message } = await getNotificationTemplate(
        channel_user_id,
        NotificationEnum.wallet_not_created
      );
      Logger.info('getSecurityEvents', message);
      return await returnSuccessResponse(reply, message);
    }

    const events = await securityService.listSecurityEvents(channel_user_id, {
      channel,
      event_type: resolvedEventType
    });

    return await returnSuccessResponse(reply, 'Security events fetched successfully', {
      events
    });
  } catch (error) {
    return returnErrorResponse('getSecurityEvents', logKey, reply, 500, 'Internal Server Error');
  }
};

export const setSecurityPin = async (
  request: FastifyRequest<{
    Body: { channel_user_id: string; pin: string; channel?: SecurityEventChannel };
  }>,
  reply: FastifyReply
): Promise<FastifyReply> => {
  const logKey = '[op:setSecurityPin]';
  try {
    if (!request.body) {
      return await returnErrorResponse(
        'setSecurityPin',
        logKey,
        reply,
        400,
        'You have to send a body with this request'
      );
    }

    const { channel_user_id, pin, channel } = request.body;

    if (!channel_user_id) {
      return await returnErrorResponse(
        'setSecurityPin',
        logKey,
        reply,
        400,
        'channel_user_id is required'
      );
    }

    if (!isValidPhoneNumber(channel_user_id)) {
      const msgError = `'${channel_user_id}' is invalid. 'channel_user_id' parameter must be a phone number (without spaces or symbols)`;
      return await returnErrorResponse('setSecurityPin', logKey, reply, 400, msgError);
    }

    const user: IUser | null = await getUser(channel_user_id);
    if (!user) {
      const { message } = await getNotificationTemplate(
        channel_user_id,
        NotificationEnum.wallet_not_created
      );
      Logger.info('setSecurityPin', message);
      return await returnSuccessResponse(reply, message);
    }

    if (!pin) {
      return await returnErrorResponseAsSuccess(
        'setSecurityPin',
        logKey,
        reply,
        'Missing pin in body',
        false,
        channel_user_id
      );
    }

    const result = await securityService.setPin(channel_user_id, pin, channel, false);

    if (!result.success) {
      return await returnErrorResponseAsSuccess(
        'setSecurityPin',
        logKey,
        reply,
        result.message,
        false,
        channel_user_id
      );
    }

    return await returnSuccessResponse(reply, result.message, {
      updated: true,
      pin_status: result.pin_status,
      last_set_at: result.last_set_at
    });
  } catch (error) {
    return returnErrorResponse('setSecurityPin', logKey, reply, 500, 'Internal Server Error');
  }
};

export const verifySecurityPin = async (
  request: FastifyRequest<{
    Body: { channel_user_id: string; pin: string; channel?: SecurityEventChannel };
  }>,
  reply: FastifyReply
): Promise<FastifyReply> => {
  const logKey = '[op:verifySecurityPin]';
  try {
    if (!request.body) {
      return await returnErrorResponse(
        'verifySecurityPin',
        logKey,
        reply,
        400,
        'You have to send a body with this request'
      );
    }

    const { channel_user_id, pin, channel } = request.body;

    if (!channel_user_id) {
      return await returnErrorResponse(
        'verifySecurityPin',
        logKey,
        reply,
        400,
        'channel_user_id is required'
      );
    }

    if (!isValidPhoneNumber(channel_user_id)) {
      const msgError = `'${channel_user_id}' is invalid. 'channel_user_id' parameter must be a phone number (without spaces or symbols)`;
      return await returnErrorResponse('verifySecurityPin', logKey, reply, 400, msgError);
    }

    const user: IUser | null = await getUser(channel_user_id);
    if (!user) {
      const { message } = await getNotificationTemplate(
        channel_user_id,
        NotificationEnum.wallet_not_created
      );
      Logger.info('verifySecurityPin', message);
      return await returnSuccessResponse(reply, message);
    }

    if (!pin) {
      return await returnErrorResponseAsSuccess(
        'verifySecurityPin',
        logKey,
        reply,
        'Missing pin in body',
        false,
        channel_user_id
      );
    }

    const result = await securityService.verifyPin(channel_user_id, pin, channel);

    return await returnSuccessResponse(reply, result.message, {
      ok: result.ok,
      pin_status: result.status,
      blocked_until: result.blocked_until,
      remaining_attempts: result.remaining_attempts
    });
  } catch (error) {
    return returnErrorResponse('verifySecurityPin', logKey, reply, 500, 'Internal Server Error');
  }
};

export const setSecurityRecoveryQuestions = async (
  request: FastifyRequest<{
    Body: {
      channel_user_id: string;
      questions: Array<{ question_id: string; answer: string }>;
      channel?: SecurityEventChannel;
    };
  }>,
  reply: FastifyReply
): Promise<FastifyReply> => {
  const logKey = '[op:setSecurityRecoveryQuestions]';
  try {
    if (!request.body) {
      return await returnErrorResponse(
        'setSecurityRecoveryQuestions',
        logKey,
        reply,
        400,
        'You have to send a body with this request'
      );
    }

    const { channel_user_id, questions, channel } = request.body;

    if (!channel_user_id) {
      return await returnErrorResponse(
        'setSecurityRecoveryQuestions',
        logKey,
        reply,
        400,
        'channel_user_id is required'
      );
    }

    if (!isValidPhoneNumber(channel_user_id)) {
      const msgError = `'${channel_user_id}' is invalid. 'channel_user_id' parameter must be a phone number (without spaces or symbols)`;
      return await returnErrorResponse(
        'setSecurityRecoveryQuestions',
        logKey,
        reply,
        400,
        msgError
      );
    }

    const user: IUser | null = await getUser(channel_user_id);
    if (!user) {
      const { message } = await getNotificationTemplate(
        channel_user_id,
        NotificationEnum.wallet_not_created
      );
      Logger.info('setSecurityRecoveryQuestions', message);
      return await returnSuccessResponse(reply, message);
    }

    if (!questions || !Array.isArray(questions)) {
      return await returnErrorResponseAsSuccess(
        'setSecurityRecoveryQuestions',
        logKey,
        reply,
        'Missing or invalid questions in body',
        false,
        channel_user_id
      );
    }

    const result = await securityService.setRecoveryQuestions(channel_user_id, questions, channel);

    if (!result.success) {
      return await returnErrorResponseAsSuccess(
        'setSecurityRecoveryQuestions',
        logKey,
        reply,
        result.message,
        false,
        channel_user_id
      );
    }

    return await returnSuccessResponse(reply, result.message, {
      updated: true,
      recovery_questions_set: result.recovery_questions_set,
      recovery_question_ids: result.recovery_question_ids
    });
  } catch (error) {
    return returnErrorResponse(
      'setSecurityRecoveryQuestions',
      logKey,
      reply,
      500,
      'Internal Server Error'
    );
  }
};

export const resetSecurityPin = async (
  request: FastifyRequest<{
    Body: {
      channel_user_id: string;
      new_pin: string;
      answers: Array<{ question_id: string; answer: string }>;
      channel?: SecurityEventChannel;
    };
  }>,
  reply: FastifyReply
): Promise<FastifyReply> => {
  const logKey = '[op:resetSecurityPin]';
  try {
    if (!request.body) {
      return await returnErrorResponse(
        'resetSecurityPin',
        logKey,
        reply,
        400,
        'You have to send a body with this request'
      );
    }

    const { channel_user_id, new_pin, answers, channel } = request.body;

    if (!channel_user_id) {
      return await returnErrorResponse(
        'resetSecurityPin',
        logKey,
        reply,
        400,
        'channel_user_id is required'
      );
    }

    if (!isValidPhoneNumber(channel_user_id)) {
      const msgError = `'${channel_user_id}' is invalid. 'channel_user_id' parameter must be a phone number (without spaces or symbols)`;
      return await returnErrorResponse('resetSecurityPin', logKey, reply, 400, msgError);
    }

    const user: IUser | null = await getUser(channel_user_id);
    if (!user) {
      const { message } = await getNotificationTemplate(
        channel_user_id,
        NotificationEnum.wallet_not_created
      );
      Logger.info('resetSecurityPin', message);
      return await returnSuccessResponse(reply, message);
    }

    if (!new_pin) {
      return await returnErrorResponseAsSuccess(
        'resetSecurityPin',
        logKey,
        reply,
        'Missing new_pin in body',
        false,
        channel_user_id
      );
    }

    if (!answers || !Array.isArray(answers)) {
      return await returnErrorResponseAsSuccess(
        'resetSecurityPin',
        logKey,
        reply,
        'Missing or invalid answers in body',
        false,
        channel_user_id
      );
    }

    const result = await securityService.resetPinWithRecovery(
      channel_user_id,
      answers,
      new_pin,
      channel
    );

    if (!result.success) {
      return await returnErrorResponseAsSuccess(
        'resetSecurityPin',
        logKey,
        reply,
        result.message,
        false,
        channel_user_id
      );
    }

    return await returnSuccessResponse(reply, result.message, {
      updated: true,
      pin_status: result.pin_status,
      last_set_at: result.last_set_at
    });
  } catch (error) {
    return returnErrorResponse('resetSecurityPin', logKey, reply, 500, 'Internal Server Error');
  }
};
