import type { FastifyInstance } from 'fastify';
import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it, vi } from 'vitest';

import { CARDANO_PREPROD_CHAIN_ID } from '../../src/config/cardanoConfig';
import { recordCardanoDerivationState } from '../../src/config/cardanoDerivationState';
import { CHATIZALO_TOKEN, DEFAULT_CHAIN_ID } from '../../src/config/constants';
import { buildServer } from '../../src/config/server';
import Blockchain from '../../src/models/blockchainModel';
import Token from '../../src/models/tokenModel';
import { UserModel } from '../../src/models/userModel';
import { cardanoSignerService } from '../../src/services/cardano/cardanoSignerService';
import { deriveCardanoAccount } from '../../src/services/cardano/cardanoWalletService';
import {
  enableCardanoPreprod,
  markCardanoDerivationVerified,
  setCardanoEnv
} from '../support/cardanoEnv';

vi.mock('../../src/helpers/envHelper', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../../src/helpers/envHelper')>();
  const { cardanoEnvHelperMock } = await import('../support/cardanoEnv');
  return cardanoEnvHelperMock(actual);
});

vi.mock('../../src/config/constants', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../../src/config/constants')>();
  const { cardanoConstantsMock } = await import('../support/cardanoEnv');
  return cardanoConstantsMock(actual);
});

/**
 * The application driven over HTTP, not through its services.
 *
 * This is the first test in the repository that exercises a real request. `buildServer()` was split
 * out of `startServer()` for exactly this, and what it proves is the part unit tests structurally
 * cannot: that the dispatch at the top of `make_transaction` really sends a Cardano request to the
 * Cardano controller, and really leaves everything else where it was.
 *
 * **Why a real socket instead of `server.inject()`.** Fastify's `inject` goes through
 * `light-my-request`, which reads `response._header` — a Node internal Bun does not expose, so the
 * call dies inside the library before the handler's answer is serialized. Binding an ephemeral port
 * and using `fetch` works on both runtimes, which matters because this repository is run under Bun.
 *
 * No chain calls happen here: the provider points at a closed port, so an accidental network access
 * fails instantly and visibly rather than making the suite depend on Koios.
 */

/** Chain id of the EVM network this instance operates on, per `.env`. */
const EVM_CHAIN_ID = DEFAULT_CHAIN_ID;

/** `CORS_ORIGINS` is `*` in development, but the middleware still demands the header be present. */
const ORIGIN = 'http://localhost';

let server: FastifyInstance;
let baseUrl: string;

/** The EVM network document the server needs to boot, with only what the schema requires. */
async function seedEvmNetwork(): Promise<void> {
  await Blockchain.create({
    name: 'Scroll Sepolia',
    family: 'evm',
    manteca_name: 'SCROLL',
    chainId: EVM_CHAIN_ID,
    rpc: 'http://127.0.0.1:1',
    rpcBundler: 'http://127.0.0.1:1',
    logo: '',
    explorer: 'https://sepolia.scrollscan.com/tx/',
    // Non-empty: Mongoose treats '' as missing on a required String path.
    marketplaceOpenseaUrl: 'https://sepolia.scrollscan.com/nft',
    environment: 'TEST',
    supportsEIP1559: true,
    externalDeposits: { lastBlockProcessed: 0, lastBlockTimestampProcessed: 0 },
    contracts: {},
    gas: { useFixedValues: false, operations: { transfer: {}, swap: {} } },
    balances: {
      paymasterMinBalance: '0.05',
      paymasterTargetBalance: '0.1',
      backendSignerMinBalance: '0.05',
      userSignerMinBalance: '0.05',
      userSignerBalanceToTransfer: '0.05'
    },
    limits: {
      transfer: { L1: { D: 14 }, L2: { D: 100 } },
      swap: { L1: { D: 14 }, L2: { D: 100 } },
      mint_nft: { L1: { D: 14 }, L2: { D: 100 } },
      mint_nft_copy: { L1: { D: 14 }, L2: { D: 100 } }
    }
  });
}

async function seedCardanoNetwork(): Promise<void> {
  await Blockchain.create({
    name: 'Cardano Preprod',
    family: 'cardano',
    chainId: CARDANO_PREPROD_CHAIN_ID,
    environment: 'TEST',
    explorer: 'https://preprod.cardanoscan.io/transaction/',
    network: 'testnet',
    providerUrl: 'http://127.0.0.1:1',
    ttlSlots: 900,
    depositConfirmations: 3,
    limits: { transfer: { L1: { D: 14 }, L2: { D: 100 } } }
  });
}

async function seedTokens(): Promise<void> {
  const limits = {
    transfer: { L1: { min: 1, max: 1000 }, L2: { min: 1, max: 1000 } },
    swap: { L1: { min: 1, max: 1000 }, L2: { min: 1, max: 1000 } }
  };
  await Token.create([
    {
      name: 'USDC',
      symbol: 'USDC',
      display_symbol: 'USDC',
      chain_id: EVM_CHAIN_ID,
      decimals: 6,
      display_decimals: 2,
      address: '0x1111111111111111111111111111111111111111',
      type: 'erc20',
      ramp_enabled: true,
      operations_limits: limits
    },
    {
      name: 'Cardano ADA',
      symbol: 'ADA',
      display_symbol: 'ADA',
      chain_id: CARDANO_PREPROD_CHAIN_ID,
      decimals: 6,
      display_decimals: 2,
      address: 'cardano:testnet:lovelace',
      type: 'variable',
      ramp_enabled: false,
      operations_limits: limits
    }
  ]);
}

/** Sends a request the way a real client would. */
async function call(
  path: string,
  init: { method?: string; body?: unknown; auth?: boolean } = {}
): Promise<{ status: number; text: string }> {
  const response = await fetch(`${baseUrl}${path}`, {
    method: init.method ?? 'GET',
    headers: {
      origin: ORIGIN,
      'content-type': 'application/json',
      ...(init.auth === false ? {} : { authorization: `Bearer ${CHATIZALO_TOKEN ?? ''}` })
    },
    body: init.body === undefined ? undefined : JSON.stringify(init.body)
  });
  return { status: response.status, text: await response.text() };
}

/**
 * Booted once for the whole file.
 *
 * `buildServer()` takes around thirty seconds here — it pulls in every controller, and the module
 * graph sits on a Windows filesystem mounted into WSL. Building it per test would spend minutes
 * booting and blow past the per-test timeout, which is what made an earlier version of this file
 * look like it was hanging.
 */
beforeAll(async () => {
  // A closed port: an accidental chain call fails instantly instead of reaching out.
  enableCardanoPreprod({ providerTimeoutMs: 1000 }, { providerUrl: 'http://127.0.0.1:1' });
  setCardanoEnv({ enabled: false });

  // Seeded before booting: the network config plugin snapshots the catalogue at startup.
  //
  // Cleared first because this runs before the shared setup's between-test pass has fired for
  // this file, so whatever the previous file left behind is still there — and `tokens.address`
  // is a unique index.
  await Promise.all([Blockchain.deleteMany({}), Token.deleteMany({})]);
  await seedEvmNetwork();
  await seedCardanoNetwork();
  await seedTokens();

  server = await buildServer();
  await server.listen({ port: 0, host: '127.0.0.1' });
  const address = server.server.address();
  baseUrl = `http://127.0.0.1:${typeof address === 'object' && address ? address.port : 0}`;
}, 180_000);

/**
 * The shared setup clears every collection between tests, so the rows the handlers read have to be
 * put back. The server's own snapshot survives — it is only a cache of the same data.
 */
beforeEach(async () => {
  // Cleared before seeding rather than trusting that it already is. The shared setup empties
  // every collection between tests, but it skips the pass while the connection is not yet
  // ready — and a skipped pass turns this into a duplicate key on `tokens.address` that has
  // nothing to do with the test that happens to be running.
  await Promise.all([Blockchain.deleteMany({}), Token.deleteMany({})]);
  await seedEvmNetwork();
  await seedCardanoNetwork();
  await seedTokens();
});

afterAll(async () => {
  await server?.close();
});

describe('GET /balance/:wallet - a Cardano address', () => {
  it('answers a base address, the shape this deployment actually issues', async () => {
    // 108 characters. Fastify's default `maxParamLength` is 100, and over it the router does not
    // error — it answers **404**, so this endpoint silently stopped existing for every Cardano
    // wallet the moment base addresses replaced enterprise ones. The previous fixture was 59
    // characters, which is why the suite stayed green through a broken endpoint.
    setCardanoEnv({ enabled: true });
    const address = deriveCardanoAccount('5491100000009').address;
    expect(address.length).toBeGreaterThan(100);

    const { status, text } = await call(`/balance/${address}`);

    expect(status).toBe(200);
    const body = JSON.parse(text);
    expect(body.data.wallets).toEqual([address]);
  });

  it('answers a bech32 address with the same shape an EVM address gets', async () => {
    setCardanoEnv({ enabled: true });
    const address = 'addr_test1vrhdandhv2ngazdseql7v5fkg5utnu629anv9zt25x8vrsqn2mhal';

    const { status, text } = await call(`/balance/${address}`);

    expect(status).toBe(200);
    const body = JSON.parse(text);
    expect(Array.isArray(body.data.balances)).toBe(true);
    expect(body.data.wallets).toEqual([address]);
    // No rows: the provider is unreachable, so every balance is zero, and a zero balance is not a
    // row here for the same reason it is not one on the EVM branch. The degradation is what is
    // being asserted -- the endpoint answers instead of going down.
    expect(body.data.balances).toEqual([]);
    expect(body.data.cardano.utxoCount).toBe(0);
  });

  it('still rejects a string that is neither a Cardano nor an EVM address', async () => {
    const { status } = await call('/balance/not-an-address');
    expect(status).toBe(400);
  });
});

describe('GET /balance_by_phone - the Cardano wallet is discoverable', () => {
  it('returns the Cardano address for a user who has never touched the chain', async () => {
    // The entry point of the whole flow: in V1 the user funds their own Cardano wallet, so they
    // have to be able to see the address before they have used it. The address is derived, not
    // looked up, which is what makes that possible — and nothing is written to get it.
    setCardanoEnv({ enabled: true });
    const phone = '5491100000001';
    await UserModel.create({
      phone_number: phone,
      wallets: [
        {
          wallet_proxy: '0x1111111111111111111111111111111111111111',
          wallet_eoa: '0x2222222222222222222222222222222222222222',
          chain_id: EVM_CHAIN_ID,
          status: 'active'
        }
      ]
    });

    const { status, text } = await call(`/balance_by_phone/?channel_user_id=${phone}`);

    expect(status).toBe(200);
    const body = JSON.parse(text);
    const expected = deriveCardanoAccount(phone).address;
    expect(body.data.wallets).toContain(expected);
    // The address is discoverable through `wallets` even with nothing in it. The balance list stays
    // consistent with the EVM one and carries no zero rows.
    expect(body.data.balances.some((row: { token: string }) => row.token === 'ADA')).toBe(false);

    // Derived, never provisioned: reading a balance must not write a wallet.
    const stored = await UserModel.findOne({ phone_number: phone });
    expect(stored?.wallets).toHaveLength(1);
  });

  it('leaves the portfolio untouched when Cardano is off', async () => {
    setCardanoEnv({ enabled: false });
    const phone = '5491100000002';
    await UserModel.create({
      phone_number: phone,
      wallets: [
        {
          wallet_proxy: '0x3333333333333333333333333333333333333333',
          wallet_eoa: '0x4444444444444444444444444444444444444444',
          chain_id: EVM_CHAIN_ID,
          status: 'active'
        }
      ]
    });

    const { text } = await call(`/balance_by_phone/?channel_user_id=${phone}`);

    const body = JSON.parse(text);
    expect(body.data.balances.some((row: { token: string }) => row.token === 'ADA')).toBe(false);
  });
});

describe('a Cardano derivation nobody verified', () => {
  /**
   * The verdict a deployment gets when one of its derivation inputs changed.
   *
   * Set through the state module rather than by arranging a real mismatch, because what is being
   * tested here is not the check — it is what the rest of the application does with its answer.
   */
  function derivationChanged(): void {
    setCardanoEnv({ enabled: true });
    recordCardanoDerivationState({ status: 'changed', scope: 'user' });
  }

  afterEach(() => {
    markCardanoDerivationVerified();
  });

  it('does not take the EVM transfer path down with it', async () => {
    // The whole reason the check stopped ending the process. A wrong Cardano derivation label used
    // to close the port, and with it every route in the product.
    derivationChanged();

    const { status, text } = await call('/make_transaction/', {
      method: 'POST',
      body: {
        channel_user_id: '5491100000001',
        to: '5491100000002',
        token: 'USDC',
        amount: '2'
      }
    });

    expect(status).toBe(200);
    expect(text).not.toContain('Cardano is not available');
  });

  it('refuses the Cardano transfer instead, with the answer the family already had', async () => {
    derivationChanged();

    const { status, text } = await call('/make_transaction/', {
      method: 'POST',
      body: {
        channel_user_id: '5491100000001',
        to: '5491100000002',
        token: 'ADA',
        amount: '2'
      }
    });

    expect(status).toBe(200);
    expect(text).toContain('Cardano is not available');
  });

  it('keeps the balance endpoint answering, without the Cardano address', async () => {
    // A read that would otherwise derive. The address is omitted rather than the request failing:
    // the user's EVM balances are not affected by this deployment's Cardano keys.
    derivationChanged();
    const phone = '5491100000007';
    await UserModel.create({
      phone_number: phone,
      wallets: [
        {
          wallet_proxy: '0x3333333333333333333333333333333333333333',
          wallet_eoa: '0x4444444444444444444444444444444444444444',
          chain_id: EVM_CHAIN_ID,
          status: 'active'
        }
      ]
    });

    const { status, text } = await call(`/balance_by_phone/?channel_user_id=${phone}`);

    expect(status).toBe(200);
    const body = JSON.parse(text);
    const cardanoAddress = cardanoSignerService.getAccount(
      phone,
      'testnet',
      CARDANO_PREPROD_CHAIN_ID
    ).address;
    expect(body.data.wallets).not.toContain(cardanoAddress);
    // And nothing was written on the way: a refused derivation must not leave a wallet row behind.
    const stored = await UserModel.findOne({ phone_number: phone });
    expect(stored?.wallets).toHaveLength(1);
  });

  it('answers the health check, which is what keeps the revision alive', async () => {
    derivationChanged();

    const { status } = await call('/ping', { auth: false });

    expect(status).toBe(200);
  });
});

describe('POST /make_transaction - dispatch', () => {
  const body = {
    channel_user_id: '5491100000001',
    to: '5491100000002',
    token: 'ADA',
    amount: '2'
  };

  it('sends an ADA request to the Cardano controller', async () => {
    // With the family switched off, the Cardano controller answers with a message only it produces.
    // That makes this a test of the dispatch rather than of the chain: no provider is touched.
    setCardanoEnv({ enabled: false });

    const { status, text } = await call('/make_transaction/', { method: 'POST', body });

    expect(status).toBe(200);
    expect(text).toContain('Cardano is not available');
  });

  it('sends a request naming the Cardano network there too', async () => {
    setCardanoEnv({ enabled: false });

    const { text } = await call('/make_transaction/', {
      method: 'POST',
      body: {
        ...body,
        to: 'addr_test1vz74kulhkqmrdrrg6u57we4pzckf07wj5e906zdpeddpz2ct8f930',
        network: 'cardano'
      }
    });

    expect(text).toContain('Cardano is not available');
  });

  it('leaves an EVM request on the EVM path', async () => {
    // The regression that matters: adding a chain must not divert the transfers that already work.
    setCardanoEnv({ enabled: true });

    const { text } = await call('/make_transaction/', {
      method: 'POST',
      body: { ...body, token: 'USDC' }
    });

    expect(text).not.toContain('Cardano is not available');
  });

  it('rejects an unauthenticated request before any of this', async () => {
    const { status } = await call('/make_transaction/', {
      method: 'POST',
      body,
      auth: false
    });

    expect(status).toBeGreaterThanOrEqual(400);
  });
});
